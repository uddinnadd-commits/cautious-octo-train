# usedtobe (Forge 1.20.1)

> you'll never get this back, you know?

A horror mod about a world you used to love. Output jar: `build/libs/usedtobe.jar`.

## How it plays

**Act 1 - the nostalgia world.** You spawn facing your old dirt hut. Open the chest: it holds the first Book and Quill
you wrote at ten ("MY BASE!!!"). Picking it up credits it as a *memory*. A few seconds later you get a compass and the
world builds the next base out in the fog. Follow the needle (the world also tells you the direction and distance).

The story is slow on purpose. There are **ten notebooks** and the world only gives you the next one a minute after you
found the last, so you have time to read it. They come in story order - silly first (the mega house, the trap house),
heartbreaking last (the zoo pen, the graveyard, the pole, the castle) - and the decay follows your progress in
five chapters, each with a title card and a set piece:

| chapter | when | what changes |
|---|---|---|
| home | start | bright, peaceful, nothing wrong |
| **the fading** | ~3 notebooks | dimmer light, music slows, a see-through kid (the **Echo**) stands far away and stares |
| **the forgetting** | ~5 | every torch near you goes out, flowers and grass tufts wither, grass rots |
| **the unbuilding** | ~7 | the animals are gone, builds crumble, cracks crawl, the Echo creeps closer when you look away |
| **the last of it** | ~9 | heavy cracks, dark red whispers, the fog closes in |
| finale | 10 | 30 seconds of cracking, then the ground opens |

A fallback timer (90 min, config) collapses the world anyway if you never look - but the clock alone can only drag the
decay about halfway; the notebooks are what really move the story.

**The nostalgia world itself** is no longer flat. Dead-flat open meadows (where the old bases live) are broken up by
terraced hill ranges, tarns with sandy shores, winding worn paths, wildflower patches, groves of old trees, a few big
climbable trees, and leftovers from a childhood: a swing set, a sandbox with a bucket, a fire ring, a bench. Notebook
bases are always built on the flattest ground the director can find, and as the decay deepens the flowers go first,
then the grass, then the paths crack.

**Act 2 - brokenmemories.** A flesh maze that pulses and breathes. The compass now points at a **Memory Heart**, sitting
on a little glowing altar. Touch it (right click) and it goes still - but the walls answer with parasites, the heartbeat
speeds up, the fog closes in, and the next heart appears further away and in a stranger place. Touch the last one
(5, config) and you wake up in the overworld with a final page.

The maze has three kinds of place, picked per 50x50-block region:

- **veins** - the claustrophobic maze: ceilings that rise and fall (some barely two blocks high), sinew posts,
  hanging tendrils with glowing tips, glowing growths, bone spikes, patches of scar tissue
- **halls** - the middle of a region opens into a pillared cathedral, ~15 blocks high, with long hanging tendrils
- **archives** - the same maze built out of your old house: planks, bookshelves, beds, tables, a lone standing torch

Parasites swim through walls; look straight at one while it's exposed and it freezes. Dying puts you back in the maze.

Render distance is low the whole time: a fog wall that tightens, plus the client's real render distance is lowered
(restored when you leave).

## Custom models and textures (all original)

- **Parasite** - segmented worm with snapping mandibles, six legs, throbbing sac (`ParasiteModel`)
- **Echo** - a ten-year-old you, see-through, fading toward the ground (`EchoModel`)
- **Memory Heart** - a hand-built multi-cube block model with an animated pulsing texture
- Blocks: old grass/dirt/stone/cobble/planks/log/leaves, **worn path**, rotted grass, cracked earth, and in the
  maze flesh, flesh floor, glowing flesh (animated), **sinew**, **scar tissue**
- All textures are painted procedurally by `tools/gen_assets.py` (tileable noise, voronoi plates, relief lighting).
  Edit the PNGs freely, or tweak the script and re-run `python3 tools/gen_assets.py` - it also regenerates every
  model, blockstate, loot table, tag, lang entry and the notebooks' text.

## Build

**GitHub:** put the *contents* of this folder in the repo root (so `settings.gradle` is at the top level), push, and
the workflow in `.github/workflows/build.yml` builds `usedtobe.jar` as a downloadable artifact. GitHub does **not**
unpack zip files, so unzip first and upload what is inside. (As a safety net the workflow unpacks a stray `.zip` in
the repo if no Gradle project is found, and it also finds the project inside a subfolder.) Pushing a tag like `v1.1.0`
also creates a GitHub Release.

**Locally** (JDK 17):

    gradle wrapper --gradle-version 8.1.1
    ./gradlew build          # -> build/libs/usedtobe.jar
    ./gradlew runClient

## Commands (op level 2)

| command | does |
|---|---|
| `/usedtobe start` | enter the nostalgia world / restart the story |
| `/usedtobe status` | notebooks, hearts and chapter |
| `/usedtobe remember` | credit the next notebook (skips ahead) |
| `/usedtobe site` | reveal the next notebook base right now (skips the quiet delay) |
| `/usedtobe heart` | touch the current heart |
| `/usedtobe stage <0-4>` | jump to a decay stage |
| `/usedtobe collapse` | trigger the collapse now |
| `/usedtobe broken` | go straight to brokenmemories |
| `/usedtobe reset` | leave, restore the overworld clock, stop auto-entering |

## Config (`config/usedtobe-common.toml`)

| option | default | |
|---|---|---|
| `memoriesRequired` | 10 | notebooks needed for the collapse (1-10). Lower = shorter game |
| `notebookDelaySeconds` | 45 | quiet time between a notebook and the next reveal |
| `siteDistance` | 110 | how far away the next base is (grows a little with the decay) |
| `collapseMinutes` | 90 | fallback timer |
| `heartsRequired` | 5 | hearts needed to wake up (1-8) |
| `autoEnterOnFirstJoin`, `fogScale`, `clampRenderDistance`, `maxParasitesPerPlayer` | | as before |

A quick run: `memoriesRequired = 5`, `heartsRequired = 3`, `collapseMinutes = 30`, `notebookDelaySeconds = 10`.
(Existing worlds keep their old config file; delete it to pick up the new defaults. Chunks already generated in an
old world stay flat - new terrain appears as you explore, or start a fresh world.)

## Notes

- The story locks the daylight/weather gamerules while it runs (the dimensions share the overworld clock for the
  sunset). The ending and `/usedtobe reset` restore them.
- Vanilla C418 music is referenced from `sounds.json`; nothing is bundled.
- `world/Noise`, `world/Terrain` and `world/MazeShape` are pure Java with no Minecraft types: they define the shape of
  both dimensions and can be compiled and previewed on their own.

## Additional realms

- `/usedtobe museum` and `/usedtobe city` remain available as optional shortcuts, but the main route is through the themed gateway shrines created around the Overworld spawn, including the Flesh Maze.
- The **Diamond Museum** is an endless quartz-and-glass gallery with custom counterfeit diamond exhibits, not real diamond blocks.
- The **SMP City** is an endless road grid with chunk-local abandoned buildings, varied interiors, rooftops, and server-era clutter.
- Entering the realms plays the existing title-card cutscenes. Minecraft's built-in **Programmer Art** resource pack is enabled on login.
- Each custom dimension creates a return gateway near its own spawn, including a cleared landing court in the Flesh Maze.


## Visual and block overhaul (1.2.0)

- Nostalgia terrain and generated childhood structures now use vanilla Minecraft blocks (grass block, dirt, stone, cobblestone, oak planks/logs/leaves, and dirt paths). The former `old_*` custom block registrations and their block/item assets have been removed.
- The Nostalgia dimension's flat-world foundation now uses vanilla stone, dirt, and grass block layers.
- The Rot uses a dedicated mottled, desaturated rotted-grass texture and fractured-earth texture.
- Flesh, flesh floor, glowing flesh, sinew, and scar tissue have a coordinated organic pixel-art texture set.
- The decay director now recognizes vanilla terrain and building materials when applying the Rot.

**Existing worlds:** because the old custom block registry IDs have been removed, back up worlds created with an earlier build before upgrading. Any previously placed `usedtobe:old_*` blocks may be treated as missing blocks by Minecraft; newly generated terrain uses vanilla blocks.


## 1.3.0 – Dimension expansion

### Gateways and discovery
- Four themed gateway sanctums are created around the Overworld world spawn when a player first joins a world: the World That Was, Diamond Museum, SMP City, and Flesh Maze.
- Each gateway is a clickable custom block with a dimension-specific name and destination.
- A return gateway is created near the player's arrival point in each custom dimension.
- Gateway structures use themed stone, glass, lighting, and framed plinths; they do not require commands or portal-frame crafting.

### Diamond Museum
- Reworked into chunk-local repeating gallery modules so structures never write into neighboring chunks during generation.
- Four vitrines, glass cases, pedestals, ceiling installations, bright central aisles, and connecting doorways per gallery module.
- Displays use the custom Counterfeit Diamond block and never place real diamond blocks as exhibits.

### SMP City
- Expanded the repeating city grid with road markings, sidewalks, varied building palettes, multiple floors, atriums, rooftops, and distinct abandoned player-base interiors.
- Added different workshop, enchanting, storage, living, and overgrown building themes.

### Validation
- Added blockstates, block/item models, textures, English names, and block loot tables for the counterfeit gem and all gateway blocks.
- JSON syntax, new block model references, texture presence, and loot-table assets were manually validated. A full Forge compile and in-game multiplayer test still need to be run in a Forge 1.20.1 development environment.
