// Preview tool (not part of the mod). From the project root:
//   javac -d /tmp/pv src/main/java/com/usedtobe/world/{Noise,Terrain,MazeShape}.java tools/preview/MazePreview.java
//   java -cp /tmp/pv MazePreview <seed>     -> writes a .ppm top-down map in the current directory
import com.usedtobe.world.MazeShape;
import java.io.*;
import java.util.*;

public class MazePreview {
    public static void main(String[] a) throws Exception {
        long seed = a.length > 0 ? Long.parseLong(a[0]) : 12345L;
        int N = 700, ox = -N / 2, oz = -N / 2;
        boolean[][] open = new boolean[N][N];
        long[] zoneCount = new long[3];
        for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
            open[z][x] = MazeShape.isOpen(seed, ox + x, oz + z);
            zoneCount[MazeShape.zoneAt(seed, ox + x, oz + z)]++;
        }
        // flood fill components
        int[][] comp = new int[N][N];
        int nc = 0; List<Integer> sizes = new ArrayList<>();
        for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
            if (!open[z][x] || comp[z][x] != 0) continue;
            nc++; int size = 0; ArrayDeque<int[]> q = new ArrayDeque<>(); q.add(new int[]{x, z}); comp[z][x] = nc;
            while (!q.isEmpty()) {
                int[] c = q.poll(); size++;
                int[][] d = {{1,0},{-1,0},{0,1},{0,-1}};
                for (int[] dd : d) { int nx = c[0]+dd[0], nz = c[1]+dd[1];
                    if (nx<0||nz<0||nx>=N||nz>=N||!open[nz][nx]||comp[nz][nx]!=0) continue;
                    comp[nz][nx] = nc; q.add(new int[]{nx, nz}); }
            }
            sizes.add(size);
        }
        int big = 0, bigIdx = 0; long totalOpen = 0;
        for (int i = 0; i < sizes.size(); i++) { totalOpen += sizes.get(i); if (sizes.get(i) > big) { big = sizes.get(i); bigIdx = i + 1; } }
        System.out.printf("components=%d largest=%d of %d open (%.2f%%)%n", nc, big, totalOpen, 100.0 * big / totalOpen);
        // components not in the main one: are they only edge artifacts? report how many of those touch the window border
        int stray = 0;
        for (int i = 0; i < sizes.size(); i++) if (i + 1 != bigIdx) stray++;
        System.out.println("strays (cells cut by window edge expected): " + stray);
        // are spawn cells connected to the main component?
        System.out.println("origin cell in main: " + (comp[-oz][-ox] == bigIdx));
        System.out.printf("zone share: veins=%.1f%% hall=%.1f%% archive=%.1f%%%n", 100.0*zoneCount[0]/(N*N), 100.0*zoneCount[1]/(N*N), 100.0*zoneCount[2]/(N*N));
        int[] hist = new int[30];
        for (int z = 0; z < N; z += 5) for (int x = 0; x < N; x += 5) if (open[z][x]) hist[MazeShape.ceilingY(seed, ox+x, oz+z) - MazeShape.FLOOR]++;
        System.out.println("air heights (above floor): " + Arrays.toString(hist));
        int propCount = 0, hangs = 0;
        for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) if (open[z][x]) {
            int zone = MazeShape.zoneAt(seed, ox+x, oz+z);
            for (int y = MazeShape.FLOOR+1; y <= MazeShape.FLOOR+3; y++) if (MazeShape.prop(seed, ox+x, y, oz+z, zone) != 0) propCount++;
            if (MazeShape.hangLength(seed, ox+x, oz+z, zone) > 0) hangs++;
        }
        System.out.println("props=" + propCount + " tendrils=" + hangs);
        try (PrintStream out = new PrintStream(new FileOutputStream("maze_" + seed + ".ppm"))) {
            out.print("P6\n" + N + " " + N + "\n255\n");
            for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
                int zone = MazeShape.zoneAt(seed, ox + x, oz + z);
                int r, g, b;
                if (!open[z][x]) { r = 30; g = 8; b = 14; if (zone == 2) { r = 70; g = 45; b = 20; } }
                else if (zone == 0) { r = 180; g = 60; b = 70; }
                else if (zone == 1) { r = 230; g = 190; b = 190; }
                else { r = 200; g = 150; b = 70; }
                if (Math.abs(ox + x) < 2 && Math.abs(oz + z) < 2) { r = 0; g = 255; b = 0; }
                out.write(r); out.write(g); out.write(b);
            }
        }
    }
}
