#!/usr/bin/env python3
"""
Generates every texture, model, loot table and data-pack file for usedtobe (standard library only).
Run from anywhere:  python3 tools/gen_assets.py
Textures are painted procedurally (tileable noise, voronoi plates, relief lighting) - edit the PNGs freely afterwards,
or tweak this script and re-run.
"""
import json
import math
import os
import random
import struct
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', 'src', 'main', 'resources'))
A = f'{ROOT}/assets/usedtobe'
D = f'{ROOT}/data/usedtobe'
MCD = f'{ROOT}/data/minecraft'


# =====================================================================================
# io helpers
# =====================================================================================
def mk(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)


def wjson(path, obj):
    mk(path)
    with open(path, 'w') as f:
        json.dump(obj, f, indent=2)


def clamp(v, lo=0, hi=255):
    return lo if v < lo else hi if v > hi else v


def save_png(path, rows):
    mk(path)
    h, w = len(rows), len(rows[0])
    raw = bytearray()
    for row in rows:
        raw.append(0)
        for c in row:
            a = c[3] if len(c) > 3 else 255
            raw += bytes((clamp(int(round(c[0]))), clamp(int(round(c[1]))), clamp(int(round(c[2]))), clamp(int(round(a)))))

    def chunk(t, d):
        body = t + d
        return struct.pack('>I', len(d)) + body + struct.pack('>I', zlib.crc32(body) & 0xffffffff)

    png = (b'\x89PNG\r\n\x1a\n'
           + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(bytes(raw), 9))
           + chunk(b'IEND', b''))
    with open(path, 'wb') as f:
        f.write(png)


# =====================================================================================
# painting toolkit
# =====================================================================================
def mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(len(a)))


def mul(c, k):
    return (c[0] * k, c[1] * k, c[2] * k)


def add(c, v):
    return (c[0] + v, c[1] + v, c[2] + v)


def ramp(t, stops):
    t = max(0.0, min(1.0, t))
    for i in range(len(stops) - 1):
        t0, c0 = stops[i]
        t1, c1 = stops[i + 1]
        if t <= t1:
            u = 0.0 if t1 == t0 else (t - t0) / (t1 - t0)
            return mix(c0, c1, u)
    return stops[-1][1]


def smooth(t):
    return t * t * (3 - 2 * t)


def tnoise(seed, n=16, cx=4, cy=None):
    """Tileable value noise in [0,1]; lattice spacing cx px across, cy px down."""
    cy = cy or cx
    gx, gy = max(1, n // cx), max(1, n // cy)
    rnd = random.Random(seed)
    lat = [[rnd.random() for _ in range(gx)] for _ in range(gy)]
    out = []
    for y in range(n):
        fy = y / cy
        y0 = int(fy)
        ty = smooth(fy - y0)
        y0 %= gy
        y1 = (y0 + 1) % gy
        row = []
        for x in range(n):
            fx = x / cx
            x0 = int(fx)
            tx = smooth(fx - x0)
            x0 %= gx
            x1 = (x0 + 1) % gx
            a = lat[y0][x0] + (lat[y0][x1] - lat[y0][x0]) * tx
            b = lat[y1][x0] + (lat[y1][x1] - lat[y1][x0]) * tx
            row.append(a + (b - a) * ty)
        out.append(row)
    return out


def fbm_t(seed, n=16, cells=(8, 4, 2), weights=(0.5, 0.3, 0.2)):
    layers = [tnoise(seed + i * 31, n, c) for i, c in enumerate(cells)]
    return [[sum(w * L[y][x] for w, L in zip(weights, layers)) for x in range(n)] for y in range(n)]


def voronoi(seed, n=16, pts=9):
    """Tileable voronoi: returns (cell id, nearest distance, second-nearest distance) grids."""
    rnd = random.Random(seed)
    P = [(rnd.uniform(0, n), rnd.uniform(0, n)) for _ in range(pts)]
    ids, d1g, d2g = [], [], []
    for y in range(n):
        ri, r1, r2 = [], [], []
        for x in range(n):
            ds = []
            for i, (px, py) in enumerate(P):
                d = min(math.hypot(x + 0.5 - px + ox, y + 0.5 - py + oy) for ox in (-n, 0, n) for oy in (-n, 0, n))
                ds.append((d, i))
            ds.sort()
            ri.append(ds[0][1])
            r1.append(ds[0][0])
            r2.append(ds[1][0])
        ids.append(ri)
        d1g.append(r1)
        d2g.append(r2)
    return ids, d1g, d2g


def relief(h, k=1.0):
    """Light from the top-left: brighter where the surface rises toward the light."""
    n = len(h)
    return [[1.0 + k * (h[y][x] - h[(y - 1) % n][(x - 1) % n]) for x in range(n)] for y in range(n)]


def new_rows(n=16, fill=(0, 0, 0)):
    return [[fill for _ in range(n)] for _ in range(n)]


def walk(rnd, rows, n, color, steps, thick=False, start=None, wrap=True, ang=None):
    x, y = start if start else (rnd.uniform(0, n), rnd.uniform(0, n))
    a = rnd.uniform(0, 6.283) if ang is None else ang
    for _ in range(steps):
        xi, yi = int(x), int(y)
        if wrap:
            xi %= n
            yi %= n
        elif not (0 <= xi < n and 0 <= yi < n):
            break
        rows[yi][xi] = color
        if thick:
            rows[yi][(xi + 1) % n] = color
        a += rnd.uniform(-0.8, 0.8)
        x += math.cos(a)
        y += math.sin(a)


# =====================================================================================
# block textures: the world you remember
# =====================================================================================
def tex_dirt(seed=1):
    n = fbm_t(seed)
    rnd = random.Random(seed + 100)
    rows = [[ramp(n[y][x], [(0, (84, 56, 34)), (0.5, (118, 82, 52)), (1, (152, 110, 74))]) for x in range(16)] for y in range(16)]
    for _ in range(6):  # pebbles with a tiny shadow
        px, py = rnd.randrange(15), rnd.randrange(14)
        c = rnd.choice([(150, 140, 126), (124, 116, 106), (172, 158, 138)])
        rows[py][px] = c
        rows[py][px + 1] = mul(c, 0.9)
        rows[py + 1][px] = mul(c, 0.62)
    for _ in range(14):  # roots and grit
        rows[rnd.randrange(16)][rnd.randrange(16)] = (58, 38, 24)
    return rows


def tex_stone(seed=2):
    n = fbm_t(seed)
    strata = tnoise(seed + 5, cx=16, cy=4)
    rnd = random.Random(seed + 100)
    rows = [[ramp(0.6 * n[y][x] + 0.4 * strata[y][x], [(0, (86, 88, 94)), (0.5, (122, 124, 128)), (1, (152, 153, 158))])
             for x in range(16)] for y in range(16)]
    for _ in range(2):  # hairline cracks with a lit lip
        x, y, a = rnd.uniform(0, 16), rnd.uniform(0, 16), rnd.uniform(0, 6.28)
        for _ in range(11):
            xi, yi = int(x) % 16, int(y) % 16
            rows[yi][xi] = (62, 64, 70)
            rows[(yi - 1) % 16][(xi - 1) % 16] = add(rows[(yi - 1) % 16][(xi - 1) % 16], 14)
            a += rnd.uniform(-0.7, 0.7)
            x += math.cos(a)
            y += math.sin(a)
    for _ in range(10):
        rows[rnd.randrange(16)][rnd.randrange(16)] = rnd.choice([(70, 72, 78), (164, 166, 170)])
    return rows


def tex_cobble(seed=3):
    ids, d1, d2 = voronoi(seed, 16, 11)
    rnd = random.Random(seed + 50)
    shade = [rnd.randint(98, 142) for _ in range(11)]
    mossy = set(rnd.sample(range(11), 2))
    height = [[min(1.0, (d2[y][x] - d1[y][x]) / 2.6) for x in range(16)] for y in range(16)]
    lit = relief(height, 0.9)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            v = shade[ids[y][x]] + rnd.randint(-7, 7)
            c = (v, v - 1, v - 4)
            if ids[y][x] in mossy and rnd.random() < 0.55:
                c = mix(c, (62, 98, 48), 0.45)
            if d2[y][x] - d1[y][x] < 0.85:
                c = (66, 64, 68)
            else:
                c = mul(c, max(0.7, min(1.25, lit[y][x])))
            row.append(c)
        rows.append(row)
    return rows


def tex_planks(seed=4):
    rnd = random.Random(seed)
    tones = [(158, 122, 76), (148, 114, 70), (166, 130, 82), (142, 108, 66)]
    seams = [rnd.randint(3, 12) for _ in range(4)]
    rows = []
    for b in range(4):
        grain = tnoise(seed + b * 7, cx=16, cy=2)
        base = mix(tones[b], (150, 140, 124), 0.18)  # weathered
        for r in range(4):
            y = b * 4 + r
            row = []
            for x in range(16):
                g = grain[y][x]
                c = mul(base, 0.86 + 0.28 * g)
                if r == 0:
                    c = mul(c, 1.10)
                if r == 3:
                    c = mul(c, 0.62)
                if x == seams[b]:
                    c = mul(c, 0.7)
                if r == 1 and x in (1, 14):
                    c = (84, 72, 62)  # nail heads
                row.append(c)
            rows.append(row)
    return rows


def tex_log_side(seed=5):
    bark = tnoise(seed, cx=2, cy=16)
    fine = tnoise(seed + 9, cx=4, cy=8)
    rnd = random.Random(seed + 2)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            t = 0.65 * bark[y][x] + 0.35 * fine[y][x]
            c = ramp(t, [(0, (40, 30, 20)), (0.4, (76, 56, 36)), (0.75, (108, 82, 54)), (1, (130, 102, 68))])
            row.append(c)
        rows.append(row)
    for _ in range(5):
        rows[rnd.randrange(16)][rnd.randrange(16)] = (112, 130, 78)  # lichen
    kx, ky = rnd.randrange(3, 12), rnd.randrange(3, 12)
    for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1)):
        rows[ky + dy][kx + dx] = (36, 26, 18)
    return rows


def tex_log_top(seed=6):
    wob = tnoise(seed, cx=4)
    rnd = random.Random(seed)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            dx, dy = x - 7.5, y - 7.5
            edge = max(abs(dx), abs(dy))
            r = math.hypot(dx, dy) + (wob[y][x] - 0.5) * 2.2
            n = rnd.randint(-5, 5)
            if edge >= 6.6:
                c = (84 + n, 62 + n, 40 + n)
            elif r < 1.3:
                c = (118 + n, 84 + n, 52 + n)
            else:
                c = (178, 144, 92) if int(r * 1.15) % 2 == 0 else (150, 118, 72)
                c = add(c, n)
            row.append(c)
        rows.append(row)
    for i in range(6):  # a drying crack
        rows[8 + i // 2][8 + i] = (80, 56, 34) if 8 + i < 16 else rows[8 + i // 2][(8 + i) % 16]
    return rows


def tex_leaves(seed=7):
    n1, n2 = tnoise(seed, cx=4), tnoise(seed + 3, cx=2)
    rnd = random.Random(seed)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            v = 0.6 * n1[y][x] + 0.4 * n2[y][x]
            c = ramp(v, [(0, (14, 44, 18)), (0.35, (30, 82, 30)), (0.6, (52, 120, 40)), (0.85, (88, 158, 58)), (1, (128, 188, 80))])
            if n2[y][x] < 0.2:
                c = (8, 26, 10)  # gaps between clumps
            row.append(c)
        rows.append(row)
    for _ in range(4):
        rows[rnd.randrange(16)][rnd.randrange(16)] = (196, 164, 56)  # the first autumn leaves
    return rows


def grass_color(t):
    return ramp(t, [(0, (56, 104, 30)), (0.5, (88, 144, 46)), (1, (128, 178, 66))])


def tex_grass_top(seed=8):
    n = fbm_t(seed, weights=(0.55, 0.3, 0.15))
    rnd = random.Random(seed + 7)
    rows = [[grass_color(max(0.0, min(1.0, (n[y][x] - 0.5) * 1.5 + 0.5))) for x in range(16)] for y in range(16)]
    for _ in range(30):  # blades
        x, y = rnd.randrange(16), rnd.randrange(15)
        rows[y][x] = add(rows[y][x], 22)
        rows[y + 1][x] = add(rows[y + 1][x], -30)
    return rows


def paint_band(rows, depths, color_fn, rnd):
    for x in range(16):
        d = depths[x]
        for y in range(d):
            c = color_fn(rnd.random())
            if y == d - 1:
                c = mul(c, 0.72)  # shadowed fringe
            rows[y][x] = c
        if rnd.random() < 0.3 and d < 7:  # a blade hanging over the dirt
            rows[d][x] = mul(color_fn(0.4), 0.82)


def tex_grass_side(seed=8):
    rows = tex_dirt(seed + 20)
    rnd = random.Random(seed + 5)
    depth = tnoise(seed + 40, cx=4)
    paint_band(rows, [3 + int(depth[0][x] * 2.6) for x in range(16)], grass_color, rnd)
    return rows


def rotted_color(t):
    return ramp(t, [(0, (68, 62, 42)), (0.5, (104, 98, 62)), (1, (140, 128, 78))])


def tex_rotted_top(seed=9):
    n = fbm_t(seed)
    n2 = tnoise(seed + 4, cx=4)
    rnd = random.Random(seed + 7)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            c = rotted_color(n[y][x])
            if n2[y][x] < 0.28:
                c = mul(c, 0.74)  # dead patches
            row.append(c)
        rows.append(row)
    for _ in range(12):
        rows[rnd.randrange(16)][rnd.randrange(16)] = (176, 154, 100)  # dried blades
    for _ in range(6):
        rows[rnd.randrange(16)][rnd.randrange(16)] = (170, 172, 150)  # mould
    return rows


def tex_rotted_side(seed=9):
    rows = tex_dirt(seed + 20)
    rnd = random.Random(seed + 5)
    depth = tnoise(seed + 40, cx=4)
    paint_band(rows, [3 + int(depth[0][x] * 3.2) for x in range(16)], rotted_color, rnd)
    return rows


def tex_cracked(seed=10):
    n = fbm_t(seed)
    ids, d1, d2 = voronoi(seed, 16, 6)
    rnd = random.Random(seed + 3)
    height = [[min(1.0, (d2[y][x] - d1[y][x]) / 3.0) for x in range(16)] for y in range(16)]
    lit = relief(height, 0.8)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            c = ramp(n[y][x], [(0, (90, 64, 48)), (1, (140, 106, 80))])
            gap = d2[y][x] - d1[y][x]
            if gap < 0.95:
                c = (34, 20, 16)
                if gap < 0.45 and rnd.random() < 0.2:
                    c = (104, 30, 16)  # something still warm down there
            else:
                c = mul(c, max(0.75, min(1.2, lit[y][x])))
            row.append(c)
        rows.append(row)
    return rows


def tex_path(seed=11):
    n = fbm_t(seed, cells=(8, 4, 2), weights=(0.45, 0.35, 0.2))
    scuff = tnoise(seed + 6, cx=8, cy=2)
    rnd = random.Random(seed + 9)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            t = 0.7 * n[y][x] + 0.3 * scuff[y][x]
            row.append(ramp(t, [(0, (126, 98, 68)), (0.5, (152, 120, 84)), (1, (182, 148, 106))]))
        rows.append(row)
    for _ in range(5):
        px, py = rnd.randrange(15), rnd.randrange(15)
        rows[py][px] = (176, 168, 150)
        rows[py + 1][px] = (104, 92, 76)
    for _ in range(8):
        rows[rnd.randrange(16)][rnd.randrange(16)] = (98, 72, 48)
    return rows


# =====================================================================================
# block textures: brokenmemories (animated: 12 frames, a heartbeat)
# =====================================================================================
def beat(t):
    return min(1.0, math.exp(-((t - 0.04) / 0.07) ** 2) + 0.7 * math.exp(-((t - 0.30) / 0.06) ** 2))


def flesh_strip(seed, base, vein, pale, bright, frames=12, glow=0.0, veins=4, fat=0.6):
    """Muscle fibre + fat + branching veins, pulsing with the heartbeat. glow>0 adds bioluminescent bulbs."""
    rnd = random.Random(seed)
    body = fbm_t(seed, weights=(0.5, 0.3, 0.2))
    fibre = tnoise(seed + 5, cx=8, cy=2)
    fatn = tnoise(seed + 9, cx=4)
    spec = tnoise(seed + 13, cx=4)
    dark = mul(base, 0.55)
    light = mix(base, pale, 0.45)

    vm = [[0] * 16 for _ in range(16)]
    halo = [[0] * 16 for _ in range(16)]
    for _ in range(veins):
        x, y, a = rnd.uniform(0, 16), rnd.uniform(0, 16), rnd.uniform(0, 6.28)
        for step in range(22):
            xi, yi = int(x) % 16, int(y) % 16
            vm[yi][xi] = 1
            vm[yi][(xi + 1) % 16] = 1
            for dx, dy in ((2, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1)):
                halo[(yi + dy) % 16][(xi + dx) % 16] = 1
            if step in (8, 15):  # a branch
                bx, by, ba = x, y, a + rnd.choice([-1, 1]) * 0.9
                for _ in range(7):
                    bxi, byi = int(bx) % 16, int(by) % 16
                    vm[byi][bxi] = 1
                    ba += rnd.uniform(-0.5, 0.5)
                    bx += math.cos(ba)
                    by += math.sin(ba)
            a += rnd.uniform(-0.6, 0.6)
            x += math.cos(a)
            y += math.sin(a)
    pores = [(rnd.randrange(16), rnd.randrange(16)) for _ in range(5)]
    bulbs = [(rnd.uniform(2, 14), rnd.uniform(2, 14), rnd.uniform(1.6, 2.6), rnd.random()) for _ in range(4)]

    strip = []
    for f in range(frames):
        t = f / frames
        b = beat(t)
        for y in range(16):
            row = []
            for x in range(16):
                sx = (x + int(round(math.sin(y * 0.9 + x * 0.3) * b * 1.2))) % 16
                sy = (y + int(round(math.cos(x * 0.8) * b * 1.0))) % 16
                m = 0.55 * body[sy][sx] + 0.45 * fibre[sy][sx]
                c = ramp(0.2 + 0.6 * m, [(0, dark), (0.5, base), (1, light)])
                if fatn[sy][sx] > 0.74 - 0.12 * fat:
                    c = mix(c, pale, 0.40)  # a vein of fat
                if halo[sy][sx] and not vm[sy][sx]:
                    c = mix(c, vein, 0.45 + 0.15 * b)
                if vm[sy][sx]:
                    c = (vein[0] + b * 165, vein[1] + b * 62, vein[2] + b * 34)
                if (sx, sy) in pores:
                    c = mul(c, 0.5)
                if glow > 0:
                    for (bx, by, br, ph) in bulbs:
                        d = min(math.hypot(sx + 0.5 - bx + ox, sy + 0.5 - by + oy) for ox in (-16, 0, 16) for oy in (-16, 0, 16))
                        if d < br:
                            pulse = 0.65 + 0.35 * beat((t + ph) % 1.0)
                            core = ramp(1.0 - d / br, [(0, (214, 96, 84)), (0.5, (250, 170, 110)), (1, (255, 238, 190))])
                            c = mix(c, core, min(1.0, glow * pulse))
                # wet shine, drifting
                sh = spec[(sy + f // 3) % 16][sx]
                if sh > 0.78:
                    c = add(c, 26 * (sh - 0.78) / 0.22 + 4)
                k = bright * (0.80 + 0.32 * b)
                row.append(mul(c, k))
            strip.append(row)
    return strip


def tex_scar(seed=14):
    n = fbm_t(seed)
    rnd = random.Random(seed)
    rows = [[ramp(n[y][x], [(0, (176, 124, 118)), (0.55, (208, 160, 150)), (1, (230, 190, 176))]) for x in range(16)] for y in range(16)]
    # a jagged stitched seam, top to bottom, with thread crossing it
    for y in range(16):
        sx = 7 + int(round(math.sin(y * 0.8) * 1.1))
        for dx in (-2, -1):
            rows[y][(sx + dx) % 16] = mul(rows[y][(sx + dx) % 16], 1.12)   # raised lip
        rows[y][sx % 16] = (122, 68, 74)
        rows[y][(sx + 1) % 16] = (150, 92, 94)
        for dx in (2, 3):
            rows[y][(sx + dx) % 16] = mul(rows[y][(sx + dx) % 16], 0.86)
        if y % 3 == 1:
            for dx in (-2, -1, 0, 1, 2):
                rows[y][(sx + dx) % 16] = (66, 40, 48) if dx in (-2, 2) else (92, 58, 62)
    for _ in range(10):
        rows[rnd.randrange(16)][rnd.randrange(16)] = (156, 104, 104)
    return rows


def tex_sinew_side(seed=15):
    fine = tnoise(seed, cx=2, cy=8)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            twist = x + 0.55 * abs((y % 16) - 8)
            s = abs((twist % 4.0) - 2.0) / 2.0           # 0 = centre of a strand, 1 = the gap between strands
            t = (1.0 - s) * 0.85 + fine[y][x] * 0.25
            c = ramp(t, [(0, (70, 18, 30)), (0.45, (150, 62, 70)), (0.8, (214, 156, 140)), (1, (242, 214, 196))])
            row.append(c)
        rows.append(row)
    return rows


def tex_sinew_top(seed=16):
    rnd = random.Random(seed)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            dx, dy = x - 7.5, y - 7.5
            edge = max(abs(dx), abs(dy))
            r = math.hypot(dx, dy)
            n = rnd.randint(-8, 8)
            if edge >= 6.6:
                c = (108 + n, 36 + n, 46 + n)
            elif r < 2.0:
                c = (236, 208, 190)
            elif int(r) % 2 == 0:
                c = (196 + n, 116 + n, 112 + n)
            else:
                c = (150 + n, 62 + n, 72 + n)
            if r >= 2.0 and edge < 6.6 and rnd.random() < 0.12:
                c = (240, 212, 196)
            row.append(c)
        rows.append(row)
    return rows


# =====================================================================================
# entity textures (UV-aware: matches texOffs(u, v).addBox(.., w, h, d) in the Java models)
# =====================================================================================
def blank(w, h):
    return [[(0, 0, 0, 0) for _ in range(w)] for _ in range(h)]


def paint_box(img, u, v, w, h, d, fn):
    faces = {
        'east': (u, v + d, d, h),
        'front': (u + d, v + d, w, h),
        'west': (u + d + w, v + d, d, h),
        'back': (u + 2 * d + w, v + d, w, h),
        'top': (u + d, v, w, d),
        'bottom': (u + d + w, v, w, d),
    }
    for name, (fx, fy, fw, fh) in faces.items():
        for y in range(fh):
            for x in range(fw):
                img[fy + y][fx + x] = fn(name, x, y, fw, fh)


def vn(seed):
    """A small cached 2D value-noise sampler for entity skins."""
    g = tnoise(seed, n=32, cx=4)
    return lambda x, y: g[int(y) % 32][int(x) % 32]


FACE_OFFSET = {'top': 1, 'bottom': 2, 'east': 3, 'west': 4, 'front': 5, 'back': 6}


def flesh_fn(seed, base=(132, 34, 46), ring=False, belly=True):
    noise = vn(seed)
    rnd = random.Random(seed)

    def fn(face, x, y, fw, fh):
        n = noise(x + FACE_OFFSET.get(face, 0) * 5, y)
        c = ramp(n, [(0, mul(base, 0.62)), (0.5, base), (1, mix(base, (230, 150, 130), 0.4))])
        r = rnd.random()
        if r < 0.05:
            c = (80, 14, 44)      # vein
        elif r < 0.075:
            c = (222, 184, 140)   # pale pustule
        if belly and face != 'top':
            c = mul(c, 1.18 - 0.5 * (y / max(1, fh - 1)))   # lit from above, dark underneath
        if face == 'bottom':
            c = mix(c, (214, 168, 120), 0.45)
        if ring and y % 4 == 3:
            c = mul(c, 0.66)
        if ring and y % 4 == 0:
            c = mul(c, 1.12)
        return (c[0], c[1], c[2], 255)
    return fn


def head_fn():
    base = flesh_fn(1, (126, 30, 42), belly=True)

    def fn(face, x, y, fw, fh):
        if face == 'front':                       # 8 x 7
            if y in (1, 2) and (x in (1, 2) or x in (5, 6)):
                if y == 2 and x in (1, 6):
                    return (12, 0, 0, 255)       # pupil
                return (240, 230, 196, 255)      # eye
            if y == 0 and x in (1, 2, 5, 6):
                return (84, 14, 40, 255)         # brow
            if y in (4, 5):                      # the mouth, with teeth
                if y == 4 and x % 2 == 1:
                    return (244, 238, 218, 255)
                if y == 5 and x % 2 == 0:
                    return (230, 224, 200, 255)
                return (34, 3, 8, 255)
        return base(face, x, y, fw, fh)
    return fn


def jaw_fn(seed):
    noise = vn(seed)

    def fn(face, x, y, fw, fh):
        n = noise(x * 2, y * 2)
        c = ramp(n, [(0, (168, 150, 118)), (0.5, (210, 194, 160)), (1, (240, 228, 200))])
        if (x + y) % 3 == 0:
            c = mul(c, 0.84)   # ridges
        return (c[0], c[1], c[2], 255)
    return fn


def sac_fn():
    noise = vn(9)

    def fn(face, x, y, fw, fh):
        n = noise(x * 2, y * 2)
        c = ramp(n, [(0, (214, 142, 92)), (0.5, (240, 186, 120)), (1, (255, 238, 190))])
        if (x * 3 + y * 5) % 11 == 0:
            c = (176, 72, 60)  # a vein through the skin
        return (c[0], c[1], c[2], 255)
    return fn


def leg_fn(face, x, y, fw, fh):
    k = 1.0 - 0.4 * (y / max(1, fh - 1))
    return (80 * k, 12 * k, 36 * k, 255)


def make_parasite():
    img = blank(64, 64)
    paint_box(img, 0, 0, 8, 7, 7, head_fn())
    paint_box(img, 32, 0, 2, 2, 5, jaw_fn(3))
    paint_box(img, 32, 8, 2, 2, 5, jaw_fn(4))
    paint_box(img, 0, 15, 10, 9, 8, flesh_fn(2, ring=True))
    paint_box(img, 0, 32, 10, 9, 8, flesh_fn(5, ring=True))
    paint_box(img, 0, 49, 8, 7, 7, flesh_fn(6, ring=True))
    paint_box(img, 36, 16, 6, 5, 6, flesh_fn(7, ring=True))
    paint_box(img, 36, 28, 4, 3, 5, flesh_fn(8))
    paint_box(img, 36, 38, 6, 3, 6, sac_fn())
    paint_box(img, 36, 48, 1, 5, 1, leg_fn)
    return img


SKIN, HAIR, SHIRT, PANTS, SHOE = (226, 176, 136), (96, 64, 38), (74, 138, 78), (74, 84, 120), (60, 42, 30)


def make_echo():
    rnd = random.Random(21)
    noise = vn(22)

    def tint(c, a, v=6):
        n = rnd.randint(-v, v)
        return (c[0] + n, c[1] + n, c[2] + n, a)

    def head(face, x, y, fw, fh):
        a = 222
        if face in ('top', 'back'):
            return tint(mul(HAIR, 0.8 + 0.4 * noise(x * 2, y * 2)), a)
        if face in ('east', 'west'):
            return tint(HAIR if y < 4 else SKIN, a)
        if face == 'bottom':
            return tint(SKIN, a)
        if y < 2 or (y == 2 and x in (0, 7)):
            return tint(mul(HAIR, 0.9 + 0.3 * noise(x, y)), a)   # fringe
        if y in (3, 4) and x in (1, 2, 5, 6):
            return (6, 6, 10, 255)                                # hollow eyes
        if y in (5, 6) and x in (1, 6) and rnd.random() < 0.9:
            return (70, 40, 48, 150)                              # where the tears ran
        if y == 6 and x in (3, 4):
            return (148, 78, 70, a)
        return tint(SKIN, a)

    def body(face, x, y, fw, fh):
        a = 205 - y * 3
        if face == 'bottom':
            return tint(PANTS, a)
        c = SHIRT
        if face == 'front' and y in (3, 4):
            c = (104, 168, 106)                                   # a stripe
        if (x + y) % 5 == 0:
            c = mul(c, 0.9)                                       # creases
        return tint(c, a)

    def arm(face, x, y, fw, fh):
        a = 200 - y * 4
        if face == 'top':
            return tint(SHIRT, a)
        if face == 'bottom':
            return tint(SKIN, a)
        return tint(SHIRT if y < 3 else SKIN, a)

    def leg(face, x, y, fw, fh):
        a = 190 - y * 12                                          # fades toward the ground
        if face == 'top':
            return tint(PANTS, a)
        if face == 'bottom':
            return tint(SHOE, a)
        return tint(PANTS if y < 5 else SHOE, a)

    img = blank(64, 64)
    paint_box(img, 0, 0, 8, 8, 8, head)
    paint_box(img, 16, 16, 6, 8, 4, body)
    paint_box(img, 40, 16, 3, 8, 3, arm)
    paint_box(img, 40, 32, 3, 8, 3, arm)
    paint_box(img, 0, 16, 3, 7, 3, leg)
    paint_box(img, 0, 32, 3, 7, 3, leg)
    return img


# =====================================================================================
# write textures
# =====================================================================================
TB = f'{A}/textures/block'
save_png(f'{TB}/old_dirt.png', tex_dirt())
save_png(f'{TB}/old_stone.png', tex_stone())
save_png(f'{TB}/old_grass_top.png', tex_grass_top())
save_png(f'{TB}/old_grass_side.png', tex_grass_side())
save_png(f'{TB}/old_cobble.png', tex_cobble())
save_png(f'{TB}/old_planks.png', tex_planks())
save_png(f'{TB}/old_log_side.png', tex_log_side())
save_png(f'{TB}/old_log_top.png', tex_log_top())
save_png(f'{TB}/old_leaves.png', tex_leaves())
save_png(f'{TB}/old_path.png', tex_path())
save_png(f'{TB}/rotted_grass_top.png', tex_rotted_top())
save_png(f'{TB}/rotted_grass_side.png', tex_rotted_side())
save_png(f'{TB}/cracked_earth.png', tex_cracked())
save_png(f'{TB}/scar_tissue.png', tex_scar())
save_png(f'{TB}/sinew_side.png', tex_sinew_side())
save_png(f'{TB}/sinew_top.png', tex_sinew_top())

for name, kw in [
    ('flesh', dict(seed=11, base=(158, 46, 46), vein=(62, 8, 24), pale=(224, 168, 146), bright=1.0)),
    ('flesh_floor', dict(seed=12, base=(116, 32, 38), vein=(52, 8, 22), pale=(186, 130, 112), bright=0.9, veins=3, fat=0.4)),
    ('flesh_glow', dict(seed=13, base=(168, 62, 58), vein=(96, 16, 40), pale=(250, 196, 168), bright=1.1, glow=0.95)),
    ('memory_heart', dict(seed=21, base=(190, 40, 56), vein=(86, 6, 30), pale=(255, 190, 170), bright=1.1, veins=6, fat=0.1)),
]:
    save_png(f'{TB}/{name}.png', flesh_strip(**kw))
    wjson(f'{TB}/{name}.png.mcmeta', {'animation': {'frametime': 2, 'interpolate': True}})

save_png(f'{A}/textures/entity/parasite.png', make_parasite())
save_png(f'{A}/textures/entity/echo.png', make_echo())

# =====================================================================================
# models / blockstates
# =====================================================================================
CUBES = ['old_dirt', 'old_stone', 'old_cobble', 'old_planks', 'old_leaves', 'old_path', 'cracked_earth',
         'flesh', 'flesh_floor', 'flesh_glow', 'scar_tissue']
for n in CUBES:
    wjson(f'{A}/models/block/{n}.json', {'parent': 'minecraft:block/cube_all', 'textures': {'all': f'usedtobe:block/{n}'}})
    wjson(f'{A}/blockstates/{n}.json', {'variants': {'': {'model': f'usedtobe:block/{n}'}}})

for n, top, side in [('old_grass', 'old_grass_top', 'old_grass_side'), ('rotted_grass', 'rotted_grass_top', 'rotted_grass_side')]:
    wjson(f'{A}/models/block/{n}.json', {
        'parent': 'minecraft:block/cube_bottom_top',
        'textures': {'top': f'usedtobe:block/{top}', 'bottom': 'usedtobe:block/old_dirt', 'side': f'usedtobe:block/{side}'}})
    wjson(f'{A}/blockstates/{n}.json', {'variants': {'': {'model': f'usedtobe:block/{n}'}}})

for n, end, side in [('old_log', 'old_log_top', 'old_log_side'), ('sinew', 'sinew_top', 'sinew_side')]:
    wjson(f'{A}/models/block/{n}.json', {
        'parent': 'minecraft:block/cube_column',
        'textures': {'end': f'usedtobe:block/{end}', 'side': f'usedtobe:block/{side}'}})
    wjson(f'{A}/blockstates/{n}.json', {'variants': {
        'axis=y': {'model': f'usedtobe:block/{n}'},
        'axis=z': {'model': f'usedtobe:block/{n}', 'x': 90},
        'axis=x': {'model': f'usedtobe:block/{n}', 'x': 90, 'y': 90}}})

BLOCKS = CUBES + ['old_grass', 'rotted_grass', 'old_log', 'sinew']
for n in BLOCKS:
    wjson(f'{A}/models/item/{n}.json', {'parent': f'usedtobe:block/{n}'})
wjson(f'{A}/models/item/parasite_spawn_egg.json', {'parent': 'minecraft:item/template_spawn_egg'})
wjson(f'{A}/models/item/echo_spawn_egg.json', {'parent': 'minecraft:item/template_spawn_egg'})


def cube(a, b):
    return {'from': a, 'to': b, 'faces': {f: {'texture': '#heart'} for f in ('north', 'south', 'east', 'west', 'up', 'down')}}


wjson(f'{A}/models/block/memory_heart.json', {
    'parent': 'minecraft:block/block',
    'textures': {'heart': 'usedtobe:block/memory_heart', 'particle': 'usedtobe:block/memory_heart'},
    'elements': [
        cube([2, 3, 3], [8, 11, 13]),     # left lobe
        cube([8, 3, 3], [14, 11, 13]),    # right lobe
        cube([4, 0, 4], [12, 4, 12]),     # base
        cube([6, 11, 5], [9, 15, 8]),     # aorta
        cube([10, 11, 8], [12, 14, 10]),  # vein
        cube([4, 11, 9], [6, 13, 11]),    # vein
    ]})
wjson(f'{A}/blockstates/memory_heart.json', {'variants': {'': {'model': 'usedtobe:block/memory_heart'}}})
wjson(f'{A}/models/item/memory_heart.json', {'parent': 'usedtobe:block/memory_heart'})

# =====================================================================================
# lang + sounds
# =====================================================================================
wjson(f'{A}/lang/en_us.json', {
    'block.usedtobe.old_grass': 'Old Grass',
    'block.usedtobe.old_dirt': 'Old Dirt',
    'block.usedtobe.old_stone': 'Old Stone',
    'block.usedtobe.old_cobble': 'Old Cobblestone',
    'block.usedtobe.old_planks': 'Old Planks',
    'block.usedtobe.old_log': 'Old Log',
    'block.usedtobe.old_leaves': 'Old Leaves',
    'block.usedtobe.old_path': 'Worn Path',
    'block.usedtobe.rotted_grass': 'Rotted Grass',
    'block.usedtobe.cracked_earth': 'Cracked Earth',
    'block.usedtobe.flesh': 'Flesh',
    'block.usedtobe.flesh_floor': 'Flesh Floor',
    'block.usedtobe.flesh_glow': 'Glowing Flesh',
    'block.usedtobe.sinew': 'Sinew',
    'block.usedtobe.scar_tissue': 'Scar Tissue',
    'block.usedtobe.memory_heart': 'Memory Heart',
    'item.usedtobe.parasite_spawn_egg': 'Parasite Spawn Egg',
    'item.usedtobe.echo_spawn_egg': 'Echo Spawn Egg',
    'entity.usedtobe.parasite': 'Parasite',
    'entity.usedtobe.echo': 'Echo',
    'effect.usedtobe.the_rot': 'The Rot',
})


def snd(name, pitch=None):
    o = {'name': name, 'stream': True}
    if pitch:
        o['pitch'] = pitch
    return o


calm = [f'minecraft:music/game/calm{i}' for i in (1, 2, 3)]
piano = [f'minecraft:music/game/piano{i}' for i in (1, 2, 3)]
hal = [f'minecraft:music/game/hal{i}' for i in (1, 2, 3, 4)]
nuance = [f'minecraft:music/game/nuance{i}' for i in (1, 2)]
menu = [f'minecraft:music/menu/menu{i}' for i in (1, 2, 3, 4)]
creative = [f'minecraft:music/game/creative/creative{i}' for i in range(1, 7)]
wjson(f'{A}/sounds.json', {
    'music.nostalgia': {'sounds': [snd(n) for n in calm + piano]},
    'music.decaying': {'sounds': [snd(n, 0.75) for n in calm + piano + hal]},
    'music.rotting': {'sounds': [snd(n, 0.55) for n in hal + nuance + calm]},
    'music.broken': {'sounds': [snd(n, 0.5) for n in menu + creative]},
})

# =====================================================================================
# data pack: dimensions, biomes, features
# =====================================================================================


def dimtype(sky, ceiling, ambient, effects):
    return {
        'ultrawarm': False, 'natural': sky, 'coordinate_scale': 1.0, 'has_skylight': sky, 'has_ceiling': ceiling,
        'ambient_light': ambient, 'piglin_safe': False, 'bed_works': False, 'respawn_anchor_works': False,
        'has_raids': False, 'logical_height': 256, 'min_y': 0, 'height': 256,
        'infiniburn': '#minecraft:infiniburn_overworld', 'effects': effects,
        'monster_spawn_light_level': 0, 'monster_spawn_block_light_limit': 0}


wjson(f'{D}/dimension_type/nostalgia.json', dimtype(True, False, 0.0, 'minecraft:overworld'))
wjson(f'{D}/dimension_type/brokenmemories.json', dimtype(False, True, 0.12, 'minecraft:the_nether'))


def flat(biome, dtype, layers):
    return {'type': f'usedtobe:{dtype}', 'generator': {'type': 'minecraft:flat', 'settings': {
        'biome': f'usedtobe:{biome}', 'lakes': False, 'features': True, 'structure_overrides': [],
        'layers': layers}}}


# The flat layers are only the bedrock of the world: the terrain feature sculpts meadows, hills and lakes on top
# of them, and the maze feature builds brokenmemories out of the flesh floor.
wjson(f'{D}/dimension/nostalgia.json', flat('remembered', 'nostalgia', [
    {'block': 'minecraft:bedrock', 'height': 1},
    {'block': 'usedtobe:old_stone', 'height': 59},
    {'block': 'usedtobe:old_dirt', 'height': 3},
    {'block': 'usedtobe:old_grass', 'height': 1}]))
wjson(f'{D}/dimension/brokenmemories.json', flat('hollow', 'brokenmemories', [
    {'block': 'minecraft:bedrock', 'height': 1},
    {'block': 'usedtobe:flesh_floor', 'height': 63}]))


def spawners(creature):
    return {'monster': [], 'creature': creature, 'ambient': [], 'axolotls': [], 'underground_water_creature': [],
            'water_creature': [], 'water_ambient': [], 'misc': []}


def feats(*steps):
    """steps: (decoration step index, feature id) pairs; 0 = raw generation, 4 = surface structures."""
    f = [[] for _ in range(11)]
    for step, fid in steps:
        f[step].append(fid)
    return f


def rgb(r, g, b):
    return (r << 16) | (g << 8) | b


wjson(f'{D}/worldgen/biome/remembered.json', {
    'temperature': 0.8, 'downfall': 0.4, 'has_precipitation': False,
    'creature_spawn_probability': 0.1,
    'effects': {
        'sky_color': 7907327, 'fog_color': 12638463,
        'water_color': rgb(74, 128, 190), 'water_fog_color': rgb(20, 50, 80),
        'grass_color': rgb(150, 184, 84), 'foliage_color': rgb(112, 156, 70)},
    'carvers': {},
    'features': feats((0, 'usedtobe:nostalgia_terrain'), (4, 'usedtobe:old_bases')),
    'spawners': spawners([
        {'type': 'minecraft:sheep', 'weight': 12, 'minCount': 2, 'maxCount': 4},
        {'type': 'minecraft:pig', 'weight': 10, 'minCount': 2, 'maxCount': 4},
        {'type': 'minecraft:chicken', 'weight': 10, 'minCount': 2, 'maxCount': 4},
        {'type': 'minecraft:cow', 'weight': 8, 'minCount': 2, 'maxCount': 4}]),
    'spawn_costs': {}})

wjson(f'{D}/worldgen/biome/hollow.json', {
    'temperature': 0.8, 'downfall': 0.4, 'has_precipitation': False,
    'creature_spawn_probability': 0.0,
    'effects': {
        'sky_color': 3802376, 'fog_color': 3802376, 'water_color': 4159204, 'water_fog_color': 329011,
        'ambient_sound': 'minecraft:ambient.crimson_forest.loop',
        'additions_sound': {'sound': 'minecraft:ambient.crimson_forest.additions', 'tick_chance': 0.0111},
        'mood_sound': {'sound': 'minecraft:ambient.crimson_forest.mood', 'tick_delay': 6000, 'block_search_extent': 8, 'offset': 2.0},
        'particle': {'probability': 0.025, 'options': {'type': 'minecraft:crimson_spore'}}},
    'carvers': {},
    'features': feats((4, 'usedtobe:memory_maze')),
    'spawners': spawners([]),
    'spawn_costs': {}})

for cfg, ftype in [('nostalgia_terrain', 'usedtobe:nostalgia_terrain'),
                   ('old_bases', 'usedtobe:nostalgia_world'),
                   ('memory_maze', 'usedtobe:memory_maze')]:
    wjson(f'{D}/worldgen/configured_feature/{cfg}.json', {'type': ftype, 'config': {}})
    wjson(f'{D}/worldgen/placed_feature/{cfg}.json', {'feature': f'usedtobe:{cfg}', 'placement': []})

# =====================================================================================
# loot tables
# =====================================================================================


def item(name, weight, lo=None, hi=None):
    e = {'type': 'minecraft:item', 'name': name, 'weight': weight}
    if lo:
        e['functions'] = [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': lo, 'max': hi}}]
    return e


wjson(f'{D}/loot_tables/chests/old_chest.json', {'type': 'minecraft:chest', 'pools': [{
    'rolls': {'type': 'minecraft:uniform', 'min': 3, 'max': 6},
    'entries': [
        item('minecraft:bread', 6, 1, 4), item('minecraft:apple', 5, 1, 3), item('minecraft:torch', 8, 4, 16),
        item('minecraft:coal', 6, 2, 8), item('minecraft:cobblestone', 7, 8, 32), item('minecraft:oak_planks', 6, 8, 24),
        item('minecraft:wooden_sword', 3), item('minecraft:stone_pickaxe', 3), item('minecraft:iron_ingot', 3, 1, 4),
        item('minecraft:cooked_porkchop', 4, 1, 3), item('minecraft:diamond', 1)]}]})

for n in BLOCKS:
    wjson(f'{D}/loot_tables/blocks/{n}.json', {'type': 'minecraft:block', 'pools': [{
        'rolls': 1.0, 'bonus_rolls': 0.0,
        'entries': [{'type': 'minecraft:item', 'name': f'usedtobe:{n}'}],
        'conditions': [{'condition': 'minecraft:survives_explosion'}]}]})


def tag(path, values):
    wjson(path, {'replace': False, 'values': values})


tag(f'{MCD}/tags/blocks/mineable/pickaxe.json', ['usedtobe:old_stone', 'usedtobe:old_cobble'])
tag(f'{MCD}/tags/blocks/mineable/axe.json', ['usedtobe:old_planks', 'usedtobe:old_log', 'usedtobe:sinew'])
tag(f'{MCD}/tags/blocks/mineable/shovel.json', ['usedtobe:old_grass', 'usedtobe:old_dirt', 'usedtobe:old_path',
                                                 'usedtobe:rotted_grass', 'usedtobe:cracked_earth'])
tag(f'{MCD}/tags/blocks/mineable/hoe.json', ['usedtobe:flesh', 'usedtobe:flesh_floor', 'usedtobe:flesh_glow',
                                              'usedtobe:scar_tissue', 'usedtobe:old_leaves'])
tag(f'{MCD}/tags/blocks/animals_spawnable_on.json', ['usedtobe:old_grass'])
# so wildflowers and grass tufts will stand on the old ground (and keep standing when a neighbour changes)
tag(f'{MCD}/tags/blocks/dirt.json', ['usedtobe:old_grass', 'usedtobe:old_dirt', 'usedtobe:old_path',
                                      'usedtobe:rotted_grass', 'usedtobe:cracked_earth'])

# =====================================================================================
# notebooks (Book and Quills a ten year old wrote)
# =====================================================================================
NOTES = {
    'first': ('my notebook #1', [
        "MY BASE!!!\nby me (age 10)\n\nthis is my secret base\nNO GIRLS NO PARENTS\n(mom can come in if she brings snacks)",
        "RULES\n1. always have torches\n2. dont dig straight down\n3. never trust a creeper\n4. write everything down so i dont forget",
        "i hid more notebooks in my other bases.\nif you find them all you will remember everything.\n\nthe compass in your pocket knows where i left them."]),
    'mega_house': ('my notebook: the mega house', [
        "THE MEGA HOUSE\n\n40 rooms (4 finished)\nkitchen: has furnace\nbedroom: has bed\nroom of doom: nothing yet\ndont go in the basement (theres no basement)",
        "dad says it looks like a lego that melted\nhe is WRONG\nits ART",
        "i was going to finish the other 36 rooms this summer."]),
    'trap': ('my notebook: DO NOT ENTER', [
        "DO NOT ENTER!!!\nTRAP HOUSE\n\nthere is a hole behind the door\nits 5 deep\nif you fall you LOSE",
        "the only person who ever fell in is me (twice)\n\nsam fell in once but he doesnt count he was cheating"]),
    'secret_base': ('my notebook: secret base', [
        "SECRET BASE #2 (shhh)\n\nits UNDERGROUND so nobody can find it\nthe door is a ladder\nthe password is 1234\n(dont tell dad)",
        "i put 3 diamonds in the chest for the ender dragon fight.\ni am going to beat it tomorrow.\n\nTOMORROW",
        "i never beat it.\ni dont remember why i stopped playing."]),
    'nether': ('my notebook: the nether', [
        "HOW TO GO TO THE NETHER\n\nstep 1: get obsidian\nstep 2: get flint\nstep 3: ???\nstep 4: NETHER",
        "i had 9 obsidian but you need 10. i was SO CLOSE.\ni will finish after dinner.",
        "(i didnt finish after dinner)"]),
    'treasure': ('my notebook: treasure map', [
        "TREASURE MAP!!\n\ni burried my best stuff under the X\ndig down 3 blocks\nDONT TELL ANYONE\nif you read this you are a pirate now",
        "pirate rules:\n1. dont ask where i got the diamonds\n2. no sharing\n3. (ok maybe sharing with sam)",
        "sam moved away in june.\ni still have his half of the map."]),
    'pen': ('my notebook: the zoo', [
        "MY ZOO\n\npets:\nbacon (pig)\nmr wool (sheep)\nchicken (just chicken)",
        "bacon fell in the hole.\ni dont want to talk about it.",
        "i miss bacon.\ni know hes not real.\ni still miss him."]),
    'graveyard': ('my notebook: RIP', [
        "RIP\n\nhere lies bacon (pig)\nhe was a good pig\nhere lies mr wool\nhere lies chicken",
        "and here lies every world i ever deleted\n\nsorry",
        "i didnt know they would stay gone."]),
    'pole': ('my notebook: the pole', [
        "THE POLE\n\ni nerd poled up here cuz it was night and i was scared\nit was only a zombie\nbut it was a BIG zombie",
        "from up here you can see all my bases\nthey look small\nthey looked so big when i was building them"]),
    'castle': ('my notebook: the castle', [
        "MY CASTLE\n\nKING: me\nQUEEN: nobody yet\nKNIGHTS: 1 wolf (he doesnt listen)",
        "DECREES\n1. everyone must be nice to me\n2. this will be the biggest castle EVER MADE",
        "its only 13 blocks wide.\ni thought it went on forever."]),
}
CORRUPT = {
    'corrupt_1': ('something wrote this', [
        "you found me.\nit was easier when you were small.\n\nthe red things are hearts. theyre what i couldnt let go of.",
        "touch them.\nit hurts them and it hurts me.\nbut its the only way out."]),
    'corrupt_2': ('something wrote this', [
        "something grew in here after you left.\nit eats the parts you stopped looking at.\n\ndont let it near you.",
        "(if you look right at it, it stops. i checked.)"]),
    'corrupt_3': ('something wrote this', [
        "its still growing. i cant stop it.\n\nevery time you touch one it learns your name.",
        "(it already knew it.)"]),
    'corrupt_4': ('something wrote this', [
        "the ones further in are the oldest.\n\nthey remember you at ten.",
        "dont be scared of the big ones.\nthey are just things you stopped looking at."]),
    'corrupt_5': ('something wrote this', [
        "last one.\nthen you can go.\n\ni dont want you to go.\ni never did.\ni know you have to."]),
}


def snbt(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'


def book_entry(title, pages, memory_id=None):
    parts = []
    if memory_id:
        parts.append('usedtobe_memory:%s' % snbt(memory_id))
    parts.append('pages:[%s]' % ','.join(snbt(p) for p in pages))
    return {'type': 'minecraft:item', 'name': 'minecraft:writable_book', 'weight': 1, 'functions': [
        {'function': 'minecraft:set_nbt', 'tag': '{%s}' % ','.join(parts)},
        {'function': 'minecraft:set_name', 'name': {'text': title, 'italic': False}}]}


def chest_table(book, filler, extra=None):
    pools = [
        {'rolls': 1, 'entries': [book]},
        {'rolls': {'type': 'minecraft:uniform', 'min': 1, 'max': 3}, 'entries': filler},
    ]
    if extra:
        pools.append({'rolls': 1, 'entries': extra})
    return {'type': 'minecraft:chest', 'pools': pools}


FILLER = [item('minecraft:bread', 6, 1, 3), item('minecraft:apple', 4, 1, 3), item('minecraft:torch', 8, 4, 12),
          item('minecraft:coal', 5, 2, 6), item('minecraft:cobblestone', 6, 8, 24), item('minecraft:wooden_sword', 2)]

for nid, (title, pages) in NOTES.items():
    extra = None
    if nid in ('secret_base', 'treasure'):
        extra = [item('minecraft:diamond', 1, 1, 3)]
    wjson(f'{D}/loot_tables/chests/book_{nid}.json', chest_table(book_entry(title, pages, nid), FILLER, extra))

for cid, (title, pages) in CORRUPT.items():
    wjson(f'{D}/loot_tables/chests/book_{cid}.json',
          chest_table(book_entry(title, pages), [item('minecraft:rotten_flesh', 5, 1, 4), item('minecraft:bone', 3, 1, 2)]))

print('assets ok')
