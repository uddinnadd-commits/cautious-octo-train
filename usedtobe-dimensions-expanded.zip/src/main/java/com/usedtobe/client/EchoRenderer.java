package com.usedtobe.client;

import com.usedtobe.UsedToBe;
import com.usedtobe.entity.EchoEntity;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Draws the echo see-through (the skin texture carries the alpha). */
public class EchoRenderer extends MobRenderer<EchoEntity, EchoModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(UsedToBe.MODID, "textures/entity/echo.png");

    public EchoRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new EchoModel(ctx.bakeLayer(EchoModel.LAYER)), 0.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(EchoEntity entity) {
        return TEXTURE;
    }

    @Override
    protected RenderType getRenderType(EchoEntity entity, boolean visible, boolean invisible, boolean glowing) {
        return RenderType.entityTranslucent(TEXTURE);
    }
}
