package com.usedtobe.client;

import com.usedtobe.Config;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraftforge.fml.loading.FMLPaths;

/**
 * Actually lowers the player's render distance inside the mod's dimensions and puts it back after.
 * The original value is also written to a tiny backup file so a crash can't leave it stuck low;
 * it gets restored the next time you join any world.
 */
final class RenderDistanceClamp {
    private static Integer saved;

    private RenderDistanceClamp() {}

    private static Path backup() {
        return FMLPaths.CONFIGDIR.get().resolve("usedtobe_renderdistance_backup.txt");
    }

    static void apply(Minecraft mc, int targetChunks) {
        if (!Config.CLAMP_RENDER_DISTANCE.get()) {
            return;
        }
        OptionInstance<Integer> opt = mc.options.renderDistance();
        int current = opt.get();
        if (saved == null) {
            saved = current;
            try {
                Files.writeString(backup(), Integer.toString(current));
            } catch (IOException ignored) {
                // not fatal
            }
        }
        if (current > targetChunks) {
            opt.set(targetChunks);
        }
    }

    static void release(Minecraft mc) {
        if (saved == null) {
            return;
        }
        mc.options.renderDistance().set(saved);
        saved = null;
        try {
            Files.deleteIfExists(backup());
        } catch (IOException ignored) {
            // not fatal
        }
    }

    static void recoverAfterCrash(Minecraft mc) {
        Path file = backup();
        if (!Files.exists(file)) {
            return;
        }
        try {
            int value = Integer.parseInt(Files.readString(file).trim());
            mc.options.renderDistance().set(value);
            mc.options.save();
            Files.deleteIfExists(file);
        } catch (Exception ignored) {
            // corrupt backup, leave it
        }
    }
}
