package com.usedtobe.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.usedtobe.UsedToBe;
import com.usedtobe.entity.ParasiteEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ParasiteRenderer extends MobRenderer<ParasiteEntity, ParasiteModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(UsedToBe.MODID, "textures/entity/parasite.png");

    public ParasiteRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new ParasiteModel(ctx.bakeLayer(ParasiteModel.LAYER)), 0.7F);
    }

    @Override
    public ResourceLocation getTextureLocation(ParasiteEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ParasiteEntity entity, PoseStack stack, float partialTick) {
        stack.scale(0.85F, 0.85F, 0.85F);
    }

    @Override
    protected float getFlipDegrees(ParasiteEntity entity) {
        return 180.0F;
    }
}
