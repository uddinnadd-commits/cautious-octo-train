package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Hidden effect used purely to sync the "decay stage" (its amplifier) from server to client,
 * so the client can scale fog, music and screen effects without custom packets.
 */
public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, UsedToBe.MODID);

    public static final RegistryObject<MobEffect> THE_ROT = EFFECTS.register("the_rot",
            () -> new MobEffect(MobEffectCategory.NEUTRAL, 0x4A0D0D) {});

    private ModEffects() {}
}
