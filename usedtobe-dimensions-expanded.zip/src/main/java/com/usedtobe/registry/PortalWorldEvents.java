package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Creates discoverable gateway sanctums at world spawn and a return gate on first arrival in each realm. */
@Mod.EventBusSubscriber(modid = UsedToBe.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PortalWorldEvents {
    private PortalWorldEvents() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        if (!level.dimension().equals(Level.OVERWORLD)) return;
        BlockPos spawn = level.getSharedSpawnPos();
        buildShrine(level, spawn.offset(28, 0, 0), ModBlocks.PORTAL_NOSTALGIA.get(),
                Blocks.CRYING_OBSIDIAN.defaultBlockState(), Blocks.PURPLE_STAINED_GLASS.defaultBlockState());
        buildShrine(level, spawn.offset(-28, 0, 0), ModBlocks.PORTAL_MUSEUM.get(),
                Blocks.QUARTZ_BLOCK.defaultBlockState(), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState());
        buildShrine(level, spawn.offset(0, 0, 28), ModBlocks.PORTAL_CITY.get(),
                Blocks.POLISHED_DEEPSLATE.defaultBlockState(), Blocks.GRAY_STAINED_GLASS.defaultBlockState());
        buildShrine(level, spawn.offset(0, 0, -28), ModBlocks.PORTAL_FLESH.get(),
                Blocks.NETHER_WART_BLOCK.defaultBlockState(), Blocks.RED_STAINED_GLASS.defaultBlockState());
    }

    @SubscribeEvent
    public static void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        var dimension = level.dimension();
        if (dimension.equals(Level.OVERWORLD) || !(dimension.equals(ModDimensions.NOSTALGIA)
                || dimension.equals(ModDimensions.BROKEN) || dimension.equals(ModDimensions.DIAMOND_MUSEUM)
                || dimension.equals(ModDimensions.SMP_CITY))) return;
        // The return pad is placed a short walk from arrival, so it never replaces the landing block.
        BlockPos near = BlockPos.containing(player.getX() + 7, 64, player.getZ() + 5);
        if (buildReturnPad(level, near)) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("A return gateway has formed nearby."), true);
        }
    }

    private static void buildShrine(ServerLevel level, BlockPos requested, net.minecraft.world.level.block.Block portal,
                                    net.minecraft.world.level.block.state.BlockState trim,
                                    net.minecraft.world.level.block.state.BlockState glass) {
        int x = requested.getX(), z = requested.getZ(), ground = Integer.MIN_VALUE;
        boolean found = false;
        // Search nearby for a genuinely clear, level 9x9 footprint; never overwrite an existing player build.
        int[] offsets = {0, 8, -8, 16, -16};
        search:
        for (int ox : offsets) for (int oz : offsets) {
            int candidateX = requested.getX() + ox, candidateZ = requested.getZ() + oz;
            int candidateGround = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, candidateX, candidateZ) - 1;
            for (int py = candidateGround - 8; py <= candidateGround + 1; py++) {
                if (level.getBlockState(new BlockPos(candidateX, py, candidateZ)).is(portal)) return;
            }
            boolean clear = true;
            for (int dx = -4; dx <= 4 && clear; dx++) for (int dz = -4; dz <= 4 && clear; dz++) {
                int gx = candidateX + dx, gz = candidateZ + dz;
                if (level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, gx, gz) - 1 != candidateGround) {
                    clear = false;
                    break;
                }
                var surface = level.getBlockState(new BlockPos(gx, candidateGround, gz));
                if (!surface.is(BlockTags.DIRT) && !surface.is(BlockTags.BASE_STONE_OVERWORLD)
                        && !surface.is(Blocks.SAND) && !surface.is(Blocks.GRAVEL) && !surface.is(Blocks.SNOW_BLOCK)) {
                    clear = false;
                    break;
                }
                for (int dy = 1; dy <= 5; dy++) {
                    if (!level.getBlockState(new BlockPos(gx, candidateGround + dy, gz)).canBeReplaced()) {
                        clear = false;
                        break;
                    }
                }
            }
            if (clear) {
                x = candidateX; z = candidateZ; ground = candidateGround; found = true;
                break search;
            }
        }
        if (!found) return; // keep the world intact if the spawn area is too crowded
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) {
            boolean rim = Math.abs(dx) == 4 || Math.abs(dz) == 4;
            level.setBlock(p.set(x + dx, ground, z + dz), rim ? trim : Blocks.SMOOTH_STONE.defaultBlockState(), 3);
            if (rim && (Math.abs(dx) + Math.abs(dz) == 8))
                level.setBlock(p.set(x + dx, ground + 1, z + dz), glass, 3);
        }
        // Portal plinth and a tall, unmistakable frame.
        for (int y = 1; y <= 4; y++) {
            level.setBlock(p.set(x - 2, ground + y, z), trim, 3);
            level.setBlock(p.set(x + 2, ground + y, z), trim, 3);
        }
        for (int dx = -2; dx <= 2; dx++) level.setBlock(p.set(x + dx, ground + 5, z), trim, 3);
        level.setBlock(p.set(x, ground + 1, z), portal.defaultBlockState(), 3);
        level.setBlock(p.set(x - 3, ground + 1, z - 3), Blocks.LANTERN.defaultBlockState(), 3);
        level.setBlock(p.set(x + 3, ground + 1, z - 3), Blocks.LANTERN.defaultBlockState(), 3);
    }

    private static boolean buildReturnPad(ServerLevel level, BlockPos near) {
        int x = near.getX(), z = near.getZ();
        // All custom flat realms have their walkable surface at Y=63; the Flesh Maze has a solid roof,
        // so a heightmap lookup would incorrectly put the return gate on top of the ceiling.
        int ground = 63;
        BlockPos portalPos = new BlockPos(x, ground + 1, z);
        if (level.getBlockState(portalPos).is(ModBlocks.PORTAL_RETURN.get())) return false;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        // Cut a small, safe landing court through the maze walls/ceilings so the return portal is reachable.
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            for (int dy = 1; dy <= 5; dy++) level.setBlock(p.set(x + dx, ground + dy, z + dz), Blocks.AIR.defaultBlockState(), 3);
            level.setBlock(p.set(x + dx, ground, z + dz),
                    Math.abs(dx) == 2 || Math.abs(dz) == 2 ? Blocks.POLISHED_DEEPSLATE.defaultBlockState()
                            : Blocks.DEEPSLATE_TILES.defaultBlockState(), 3);
        }
        level.setBlock(portalPos, ModBlocks.PORTAL_RETURN.get().defaultBlockState(), 3);
        for (int dx : new int[]{-2, 2}) {
            level.setBlock(p.set(x + dx, ground + 1, z - 2), Blocks.SOUL_LANTERN.defaultBlockState(), 3);
        }
        return true;
    }
}
