package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import com.usedtobe.block.MemoryHeartBlock;
import com.usedtobe.block.DimensionPortalBlock;
import java.util.function.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, UsedToBe.MODID);

    private static BlockBehaviour.Properties props(MapColor color, float hardness, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(hardness).sound(sound);
    }

    private static <T extends Block> RegistryObject<T> reg(String name, Supplier<T> supplier) {
        RegistryObject<T> block = BLOCKS.register(name, supplier);
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    // ---- dimensional gateways ----
    private static BlockBehaviour.Properties portalProps(MapColor color) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(3.0F, 6.0F)
                .sound(SoundType.AMETHYST).lightLevel(state -> 9).noOcclusion();
    }
    public static final RegistryObject<Block> PORTAL_NOSTALGIA = reg("portal_nostalgia", () ->
            new DimensionPortalBlock(portalProps(MapColor.COLOR_PURPLE), ModDimensions.NOSTALGIA, "The World That Was"));
    public static final RegistryObject<Block> PORTAL_MUSEUM = reg("portal_museum", () ->
            new DimensionPortalBlock(portalProps(MapColor.COLOR_LIGHT_BLUE), ModDimensions.DIAMOND_MUSEUM, "The Diamond Museum"));
    public static final RegistryObject<Block> PORTAL_CITY = reg("portal_city", () ->
            new DimensionPortalBlock(portalProps(MapColor.COLOR_GRAY), ModDimensions.SMP_CITY, "The SMP City"));
    public static final RegistryObject<Block> PORTAL_FLESH = reg("portal_flesh", () ->
            new DimensionPortalBlock(portalProps(MapColor.COLOR_RED), ModDimensions.BROKEN, "The Flesh Maze"));
    public static final RegistryObject<Block> PORTAL_RETURN = reg("portal_return", () ->
            new DimensionPortalBlock(portalProps(MapColor.COLOR_PURPLE), net.minecraft.world.level.Level.OVERWORLD, "The Overworld"));

    // Museum exhibits are deliberately imitation gemstones, never real diamond blocks.
    public static final RegistryObject<Block> FAKE_DIAMOND = reg("fake_diamond", () ->
            new Block(props(MapColor.COLOR_LIGHT_BLUE, 1.5F, SoundType.GLASS).requiresCorrectToolForDrops()));

    // ---- what it is turning into ----
    public static final RegistryObject<Block> ROTTED_GRASS = reg("rotted_grass", () -> new Block(props(MapColor.COLOR_GRAY, 0.6F, SoundType.GRASS)));
    public static final RegistryObject<Block> CRACKED_EARTH = reg("cracked_earth", () -> new Block(props(MapColor.COLOR_BROWN, 0.6F, SoundType.GRAVEL)));

    // ---- brokenmemories ----
    public static final RegistryObject<Block> FLESH = reg("flesh", () -> new Block(props(MapColor.COLOR_RED, 1.0F, SoundType.WART_BLOCK)));
    public static final RegistryObject<Block> FLESH_FLOOR = reg("flesh_floor", () -> new Block(props(MapColor.CRIMSON_NYLIUM, 1.0F, SoundType.WART_BLOCK)));
    public static final RegistryObject<Block> FLESH_GLOW = reg("flesh_glow", () -> new Block(props(MapColor.COLOR_PINK, 1.0F, SoundType.WART_BLOCK).lightLevel(state -> 7)));

    public static final RegistryObject<RotatedPillarBlock> SINEW = reg("sinew", () -> new RotatedPillarBlock(props(MapColor.COLOR_RED, 1.0F, SoundType.WART_BLOCK)));
    public static final RegistryObject<Block> SCAR_TISSUE = reg("scar_tissue", () -> new Block(props(MapColor.COLOR_PINK, 1.0F, SoundType.WART_BLOCK)));

    public static final RegistryObject<Block> MEMORY_HEART = reg("memory_heart", () -> new MemoryHeartBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(-1.0F, 3600000.0F)
                    .sound(SoundType.WART_BLOCK).lightLevel(state -> 10).noOcclusion()));

    private ModBlocks() {}
}
