package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import com.usedtobe.world.MazeFeature;
import com.usedtobe.world.NostalgiaFeature;
import com.usedtobe.world.TerrainFeature;
import com.usedtobe.world.DiamondMuseumFeature;
import com.usedtobe.world.SmpCityFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, UsedToBe.MODID);

    public static final RegistryObject<Feature<NoneFeatureConfiguration>> NOSTALGIA_TERRAIN =
            FEATURES.register("nostalgia_terrain", TerrainFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> NOSTALGIA_WORLD =
            FEATURES.register("nostalgia_world", NostalgiaFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> MEMORY_MAZE =
            FEATURES.register("memory_maze", MazeFeature::new);

    public static final RegistryObject<Feature<NoneFeatureConfiguration>> DIAMOND_MUSEUM =
            FEATURES.register("diamond_museum", DiamondMuseumFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> SMP_CITY =
            FEATURES.register("smp_city", SmpCityFeature::new);

    private ModFeatures() {}
}
