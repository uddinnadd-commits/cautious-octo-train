package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public final class ModDimensions {
    public static final ResourceKey<Level> NOSTALGIA = key("nostalgia");
    public static final ResourceKey<Level> BROKEN = key("brokenmemories");
    public static final ResourceKey<Level> DIAMOND_MUSEUM = key("diamond_museum");
    public static final ResourceKey<Level> SMP_CITY = key("smp_city");
    private static ResourceKey<Level> key(String name) {
        return ResourceKey.create(Registries.DIMENSION, new ResourceLocation(UsedToBe.MODID, name));
    }
    private ModDimensions() {}
}
