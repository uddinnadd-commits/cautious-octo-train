package com.usedtobe.world;

import com.usedtobe.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Chunk-safe, endlessly repeating museum galleries. Every displayed gemstone is an imitation. */
public class DiamondMuseumFeature extends Feature<NoneFeatureConfiguration> {
    public DiamondMuseumFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        int bx = origin.getX(), bz = origin.getZ(), floor = 64;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        long seed = Noise.mix(level.getSeed(), Math.floorDiv(bx, 16), 0, Math.floorDiv(bz, 16));

        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            boolean edge = x == 0 || x == 15 || z == 0 || z == 15;
            boolean corner = (x == 0 || x == 15) && (z == 0 || z == 15);
            level.setBlock(p.set(bx + x, floor, bz + z),
                    ((x + z) & 3) == 0 ? Blocks.POLISHED_DIORITE.defaultBlockState() : Blocks.SMOOTH_QUARTZ.defaultBlockState(), 2);
            // Each chunk is a room module, with doorways centered on all four sides.
            for (int y = 1; y <= 8; y++) {
                boolean doorway = y <= 3 && ((z == 0 || z == 15) && x >= 6 && x <= 9
                        || (x == 0 || x == 15) && z >= 6 && z <= 9);
                if (edge && !doorway && y <= 6) {
                    level.setBlock(p.set(bx + x, floor + y, bz + z),
                            y >= 2 && y <= 5 ? Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState()
                                    : Blocks.QUARTZ_BLOCK.defaultBlockState(), 2);
                } else if (edge && !doorway && y == 7) {
                    level.setBlock(p.set(bx + x, floor + y, bz + z), Blocks.CYAN_STAINED_GLASS.defaultBlockState(), 2);
                } else if (y == 8) {
                    level.setBlock(p.set(bx + x, floor + y, bz + z),
                            ((x + z) % 4 == 0) ? Blocks.SEA_LANTERN.defaultBlockState() : Blocks.QUARTZ_BLOCK.defaultBlockState(), 2);
                }
            }
            if (corner) for (int y = 1; y <= 7; y++)
                level.setBlock(p.set(bx + x, floor + y, bz + z), Blocks.QUARTZ_PILLAR.defaultBlockState(), 2);
        }

        // Four glass vitrines per room. The centerpiece is a deliberately counterfeit gem.
        int[][] displays = {{3, 3}, {12, 3}, {3, 12}, {12, 12}};
        for (int i = 0; i < displays.length; i++) {
            int x = displays[i][0], z = displays[i][1];
            var pedestal = (i % 2 == 0 ? Blocks.POLISHED_BLACKSTONE : Blocks.PRISMARINE_BRICKS).defaultBlockState();
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                level.setBlock(p.set(bx + x + dx, floor + 1, bz + z + dz), pedestal, 2);
                if (Math.abs(dx) == 1 || Math.abs(dz) == 1)
                    for (int y = 2; y <= 4; y++) level.setBlock(p.set(bx + x + dx, floor + y, bz + z + dz), Blocks.GLASS.defaultBlockState(), 2);
            }
            level.setBlock(p.set(bx + x, floor + 2, bz + z), ModBlocks.FAKE_DIAMOND.get().defaultBlockState(), 2);
            level.setBlock(p.set(bx + x, floor + 3, bz + z), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), 2);
            level.setBlock(p.set(bx + x, floor + 5, bz + z), Blocks.END_ROD.defaultBlockState(), 2);
        }

        // A bright central aisle and a rotating, seed-varied ceiling installation.
        for (int i = 2; i < 14; i++) {
            level.setBlock(p.set(bx + 7, floor + 1, bz + i), Blocks.SEA_LANTERN.defaultBlockState(), 2);
            level.setBlock(p.set(bx + 8, floor + 1, bz + i), Blocks.SEA_LANTERN.defaultBlockState(), 2);
        }
        int accent = (int) Math.floorMod(seed, 4);
        var accentBlock = switch (accent) {
            case 0 -> Blocks.CYAN_STAINED_GLASS.defaultBlockState();
            case 1 -> Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState();
            case 2 -> Blocks.PURPLE_STAINED_GLASS.defaultBlockState();
            default -> Blocks.WHITE_STAINED_GLASS.defaultBlockState();
        };
        for (int x = 5; x <= 10; x++) for (int z = 5; z <= 10; z++)
            if (x == 5 || x == 10 || z == 5 || z == 10)
                level.setBlock(p.set(bx + x, floor + 7, bz + z), accentBlock, 2);
        return true;
    }
}
