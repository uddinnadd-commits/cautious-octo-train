package com.usedtobe.world;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Infinite chunk-local city grid: varied abandoned bases, apartments, shops and server roads. */
public class SmpCityFeature extends Feature<NoneFeatureConfiguration> {
    public SmpCityFeature() { super(NoneFeatureConfiguration.CODEC); }

    @Override public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        int bx = origin.getX(), bz = origin.getZ(), y = 64;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        long hash = Noise.mix(level.getSeed(), Math.floorDiv(bx, 16), 0, Math.floorDiv(bz, 16));
        int style = (int) Math.floorMod(hash, 6), floors = 2 + (int) Math.floorMod(hash >>> 4, 5);
        int height = floors * 4 + 1;

        // A continuous 32-block road grid, with sidewalks, lane dashes and occasional lamps.
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            int wx = Math.floorMod(bx + x, 32), wz = Math.floorMod(bz + z, 32);
            boolean roadX = wx < 6, roadZ = wz < 6, road = roadX || roadZ;
            var ground = road ? (wx == 0 || wz == 0 ? Blocks.STONE_BRICKS : Blocks.GRAY_CONCRETE)
                    : Blocks.STONE_BRICKS;
            level.setBlock(p.set(bx + x, y - 1, bz + z), ground.defaultBlockState(), 2);
            if (road && ((roadX && wz == 3) || (roadZ && wx == 3))
                    && Math.floorMod((bx + x) + (bz + z), 8) < 3)
                level.setBlock(p.set(bx + x, y, bz + z), Blocks.YELLOW_CONCRETE.defaultBlockState(), 2);
            if (wx == 2 && wz == 2) {
                level.setBlock(p.set(bx + x, y, bz + z), Blocks.LIGHT.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x, y + 1, bz + z), Blocks.IRON_BARS.defaultBlockState(), 2);
            }
        }

        // Each chunk gets a building plot in the area left clear by the continuous road grid.
        int x1 = Math.floorMod(bx, 32) < 6 ? 7 : 2;
        int z1 = Math.floorMod(bz, 32) < 6 ? 7 : 2;
        int x2 = 15, z2 = 15;
        int midX = (x1 + x2) / 2, midZ = (z1 + z2) / 2;
        var wall = switch (style) {
            case 0 -> Blocks.BRICKS.defaultBlockState();
            case 1 -> Blocks.WHITE_CONCRETE.defaultBlockState();
            case 2 -> Blocks.OAK_PLANKS.defaultBlockState();
            case 3 -> Blocks.COBBLESTONE.defaultBlockState();
            case 4 -> Blocks.POLISHED_ANDESITE.defaultBlockState();
            default -> Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        };
        var interiorFloor = style == 2 ? Blocks.OAK_PLANKS.defaultBlockState() : Blocks.SMOOTH_STONE.defaultBlockState();
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) {
            boolean edge = x == x1 || x == x2 || z == z1 || z == z2;
            level.setBlock(p.set(bx + x, y, bz + z), interiorFloor, 2);
            for (int yy = 1; yy <= height; yy++) {
                if (edge) {
                    boolean window = yy % 4 == 2 && ((x + z + style) % 3 != 0);
                    level.setBlock(p.set(bx + x, y + yy, bz + z),
                            window ? (style % 2 == 0 ? Blocks.GLASS_PANE.defaultBlockState() : Blocks.TINTED_GLASS.defaultBlockState()) : wall, 2);
                } else if (yy % 4 == 0) {
                    level.setBlock(p.set(bx + x, y + yy, bz + z), interiorFloor, 2);
                }
            }
        }
        // Flat roof, stairwell, and a lit central atrium.
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++)
            level.setBlock(p.set(bx + x, y + height + 1, bz + z), Blocks.STONE_BRICK_SLAB.defaultBlockState(), 2);
        for (int yy = 1; yy < height; yy++) {
            level.setBlock(p.set(bx + midX, y + yy, bz + midZ), Blocks.AIR.defaultBlockState(), 2);
            level.setBlock(p.set(bx + midX + 1, y + yy, bz + midZ), Blocks.AIR.defaultBlockState(), 2);
        }
        level.setBlock(p.set(bx + midX, y + height, bz + midZ), Blocks.SEA_LANTERN.defaultBlockState(), 2);
        level.setBlock(p.set(bx + midX, y + 1, bz + z1), Blocks.AIR.defaultBlockState(), 2);
        level.setBlock(p.set(bx + midX, y + 2, bz + z1), Blocks.AIR.defaultBlockState(), 2);

        // Seeded interior clutter makes each abandoned plot feel like a different former player base.
        switch (style) {
            case 0 -> {
                level.setBlock(p.set(bx + x1 + 2, y + 1, bz + z1 + 2), Blocks.CRAFTING_TABLE.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x1 + 3, y + 1, bz + z1 + 2), Blocks.FURNACE.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x2 - 2, y + 1, bz + z2 - 2), Blocks.CHEST.defaultBlockState(), 2);
            }
            case 1 -> {
                level.setBlock(p.set(bx + x1 + 2, y + 1, bz + z2 - 2), Blocks.BOOKSHELF.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x1 + 3, y + 1, bz + z2 - 2), Blocks.ENCHANTING_TABLE.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x2 - 2, y + 1, bz + z1 + 2), Blocks.ANVIL.defaultBlockState(), 2);
            }
            case 2 -> {
                level.setBlock(p.set(bx + x1 + 2, y + 1, bz + z1 + 2), Blocks.RED_BED.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x2 - 2, y + 1, bz + z2 - 2), Blocks.BARREL.defaultBlockState(), 2);
            }
            case 3 -> {
                level.setBlock(p.set(bx + x1 + 2, y + 1, bz + z1 + 2), Blocks.SMITHING_TABLE.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x2 - 2, y + 1, bz + z2 - 2), Blocks.BLAST_FURNACE.defaultBlockState(), 2);
            }
            case 4 -> {
                level.setBlock(p.set(bx + x1 + 2, y + 1, bz + z1 + 2), Blocks.CARTOGRAPHY_TABLE.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x2 - 2, y + 1, bz + z2 - 2), Blocks.LOOM.defaultBlockState(), 2);
            }
            default -> {
                level.setBlock(p.set(bx + x1 + 2, y + 1, bz + z1 + 2), Blocks.COBWEB.defaultBlockState(), 2);
                level.setBlock(p.set(bx + x2 - 2, y + 1, bz + z2 - 2), Blocks.MOSSY_COBBLESTONE.defaultBlockState(), 2);
            }
        }
        // Broken rooftop antennas and occasional overgrown patches.
        if (Math.floorMod(hash >>> 12, 3) == 0) {
            for (int yy = 1; yy <= 4; yy++) level.setBlock(p.set(bx + x2 - 2, y + height + yy, bz + z2 - 2), Blocks.IRON_BARS.defaultBlockState(), 2);
            level.setBlock(p.set(bx + x2 - 2, y + height + 5, bz + z2 - 2), Blocks.LANTERN.defaultBlockState(), 2);
        }
        return true;
    }
}
