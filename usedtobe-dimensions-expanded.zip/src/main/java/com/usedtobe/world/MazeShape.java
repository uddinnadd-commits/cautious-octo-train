package com.usedtobe.world;

/**
 * The shape of brokenmemories. Pure functions of (seed, x, z) so the generator can work chunk by chunk with no
 * stored state and the story director can ask "what kind of place is this?" without touching the world.
 *
 * The skeleton is the old binary-tree maze: 5x5 cells (3x3 floor + 2-wide connectors + a 2x2 post). On top of it,
 * every 10x10-cell region picks a character:
 *   VEINS   - the claustrophobic flesh maze, ceilings that rise and fall, sinew posts, hanging tendrils
 *   HALL    - the middle of the region opens into a pillared cathedral, ceiling 15 high
 *   ARCHIVE - the same maze built out of your old house: planks, bookshelves, beds, a lone torch
 */
public final class MazeShape {
    public static final int CELL = 5;
    public static final int REGION = 10;          // cells per region side
    public static final int FLOOR = 63;           // top block of the floor layers
    public static final int TOP = FLOOR + 19;     // everything from the ceiling up to here is solid

    public static final int ZONE_VEINS = 0;
    public static final int ZONE_HALL = 1;
    public static final int ZONE_ARCHIVE = 2;

    // floor/prop codes (MazeFeature maps these to blocks)
    public static final int PROP_NONE = 0;
    public static final int PROP_GLOW = 1;        // a lump of glowing flesh on the floor
    public static final int PROP_BONE = 2;        // a short spike of bone
    public static final int PROP_BED_FOOT = 3;
    public static final int PROP_BED_HEAD = 4;
    public static final int PROP_SHELF = 5;       // bookshelf, two high
    public static final int PROP_TABLE_LEG = 6;   // fence post...
    public static final int PROP_TABLE_TOP = 7;   // ...with a pressure plate on top
    public static final int PROP_TORCH = 8;
    public static final int PROP_TUMOR = 9;       // pale scar bump

    private static final long S_ZONE = 0xB0B0A001L;
    private static final long S_CELL = 0xB0B0A002L;
    private static final long S_POST = 0xB0B0A003L;
    private static final long S_HANG = 0xB0B0A004L;
    private static final long S_PROP = 0xB0B0A005L;
    private static final long S_SCAR = 0xB0B0A006L;
    private static final long S_WALL = 0xB0B0A007L;

    private MazeShape() {}

    // ------------------------------------------------------------------ zones

    private static int regionZone(long seed, int rx, int rz) {
        if (rx == 0 && rz == 0) {
            return ZONE_VEINS; // where you land the first time is always the plain maze
        }
        double r = Noise.unit(seed ^ S_ZONE, rx, rz);
        return r < 0.44D ? ZONE_VEINS : r < 0.74D ? ZONE_HALL : ZONE_ARCHIVE;
    }

    /** True for cells in the opened-up middle of a hall region (the outer ring of cells stays maze). */
    public static boolean hallCell(long seed, int cx, int cz) {
        int rx = Math.floorDiv(cx, REGION);
        int rz = Math.floorDiv(cz, REGION);
        if (regionZone(seed, rx, rz) != ZONE_HALL) {
            return false;
        }
        int lx = Math.floorMod(cx, REGION);
        int lz = Math.floorMod(cz, REGION);
        long h = Noise.mix(seed ^ S_ZONE, rx, 11, rz);  // every hall gets its own footprint
        int x0 = 1 + (int) ((h & 3L) % 3L);
        int x1 = REGION - 2 - (int) (((h >>> 3) & 3L) % 3L);
        int z0 = 1 + (int) (((h >>> 6) & 3L) % 3L);
        int z1 = REGION - 2 - (int) (((h >>> 9) & 3L) % 3L);
        return lx >= x0 && lx <= x1 && lz >= z0 && lz <= z1;
    }

    public static int zoneAt(long seed, int x, int z) {
        int cx = Math.floorDiv(x, CELL);
        int cz = Math.floorDiv(z, CELL);
        if (hallCell(seed, cx, cz)) {
            return ZONE_HALL;
        }
        int zone = regionZone(seed, Math.floorDiv(cx, REGION), Math.floorDiv(cz, REGION));
        return zone == ZONE_ARCHIVE ? ZONE_ARCHIVE : ZONE_VEINS;
    }

    // ------------------------------------------------------------------ layout

    /** Is this column open air (a floor/corridor), as opposed to wall? */
    public static boolean isOpen(long seed, int x, int z) {
        int cx = Math.floorDiv(x, CELL);
        int cz = Math.floorDiv(z, CELL);
        int lx = Math.floorMod(x, CELL);
        int lz = Math.floorMod(z, CELL);
        boolean inX = lx < 3;
        boolean inZ = lz < 3;
        if (inX && inZ) {
            return true;
        }
        if (!inX && !inZ) {
            return !isPostSolid(seed, cx, cz); // the corner post; halls keep only some of theirs
        }
        long h = Noise.mix(seed, cx, 7, cz);
        boolean east = (h & 1L) == 0L;
        boolean both = Math.floorMod(h >>> 8, 9L) == 0L; // occasional loop
        if (!inX) {
            if (hallCell(seed, cx, cz) && hallCell(seed, cx + 1, cz)) {
                return true;
            }
            return east || both;       // east connector
        }
        if (hallCell(seed, cx, cz) && hallCell(seed, cx, cz + 1)) {
            return true;
        }
        return !east || both;          // north connector
    }

    /** Posts are always solid in the maze; inside halls only about a third survive, as pillars. */
    public static boolean isPostSolid(long seed, int cx, int cz) {
        if (!hallCell(seed, cx, cz)) {
            return true;
        }
        return Math.floorMod(Noise.mix(seed ^ S_POST, cx, 1, cz), 3L) == 0L;
    }

    public static boolean isPost(int x, int z) {
        return Math.floorMod(x, CELL) >= 3 && Math.floorMod(z, CELL) >= 3;
    }

    /** y of the first ceiling block above this column's open air. */
    public static int ceilingY(long seed, int x, int z) {
        int cx = Math.floorDiv(x, CELL);
        int cz = Math.floorDiv(z, CELL);
        if (hallCell(seed, cx, cz)) {
            return FLOOR + 15 + (int) Math.floorMod(Noise.mix(seed ^ S_CELL, cx, 2, cz), 3L);
        }
        int[] air = {3, 4, 4, 5, 5, 5, 6, 6, 7, 8, 9};
        int idx = (int) Math.floorMod(Noise.mix(seed ^ S_CELL, cx, 3, cz), (long) air.length);
        return FLOOR + 1 + air[idx];
    }

    // ------------------------------------------------------------------ surfaces

    /** True where the floor is pale scar tissue instead of raw flesh. */
    public static boolean isScar(long seed, int x, int z, int zone) {
        double n = Noise.value(seed ^ S_SCAR, x * 0.30D, z * 0.30D);
        return zone == ZONE_HALL ? n > -0.15D : n > 0.42D;
    }

    /** What stands on the floor of an open column. */
    public static int prop(long seed, int x, int y, int z, int zone) {
        int lx = Math.floorMod(x, CELL);
        int lz = Math.floorMod(z, CELL);
        int cx = Math.floorDiv(x, CELL);
        int cz = Math.floorDiv(z, CELL);
        int dy = y - FLOOR;                       // 1 = standing on the floor
        if (dy < 1 || dy > 3) {
            return PROP_NONE;
        }
        if (zone == ZONE_ARCHIVE) {
            if (lx > 2 || lz > 2) {
                return PROP_NONE;                 // connectors stay clear
            }
            int kind = (int) Math.floorMod(Noise.mix(seed ^ S_PROP, cx, 5, cz), 12L);
            switch (kind) {
                case 0: // a bed, foot then head
                    if (dy == 1 && lx == 1 && lz == 0) {
                        return PROP_BED_FOOT;
                    }
                    if (dy == 1 && lx == 1 && lz == 1) {
                        return PROP_BED_HEAD;
                    }
                    return PROP_NONE;
                case 1: // a wall of books
                    return lz == 0 && dy <= 2 ? PROP_SHELF : PROP_NONE;
                case 2: // a table
                    if (lx == 1 && lz == 1) {
                        return dy == 1 ? PROP_TABLE_LEG : dy == 2 ? PROP_TABLE_TOP : PROP_NONE;
                    }
                    return PROP_NONE;
                case 3: // somebody left a torch standing
                    return dy == 1 && lx == 1 && lz == 1 ? PROP_TORCH : PROP_NONE;
                default:
                    return PROP_NONE;
            }
        }
        if (dy != 1 && !(zone == ZONE_VEINS && dy == 2)) {
            return PROP_NONE;
        }
        double u = Noise.unit(seed ^ S_PROP, x, z * 7 + 13);
        if (zone == ZONE_HALL) {
            if (dy == 1 && u < 0.010D) {
                return PROP_TUMOR;
            }
            return PROP_NONE;
        }
        if (dy == 1 && u < 0.012D) {
            return PROP_GLOW;
        }
        if (dy == 1 && u > 0.994D) {
            return PROP_BONE;
        }
        return PROP_NONE;
    }

    /** Length of the tendril hanging from the ceiling of this open column (0 = none). */
    public static int hangLength(long seed, int x, int z, int zone) {
        double u = Noise.unit(seed ^ S_HANG, x, z);
        if (zone == ZONE_ARCHIVE) {
            return 0;
        }
        if (zone == ZONE_HALL) {
            return u < 0.020D ? 4 + (int) (u * 300.0D) % 7 : 0;
        }
        return u < 0.016D ? 1 + (int) (u * 400.0D) % 4 : 0;
    }

    // ------------------------------------------------------------------ walls

    public static final int WALL_FLESH = 0;
    public static final int WALL_GLOW = 1;
    public static final int WALL_PLANKS = 2;
    public static final int WALL_COBBLE = 3;
    public static final int WALL_DIRT = 4;
    public static final int WALL_SINEW = 5;
    public static final int WALL_SHELF = 6;
    public static final int WALL_SHROOM = 7;
    public static final int WALL_SCAR = 8;

    /** What a solid column is made of at height y (FLOOR+1 .. TOP). */
    public static int wall(long seed, int x, int y, int z, int zone) {
        long m = Noise.mix(seed ^ S_WALL, x, y, z);
        int r = (int) Math.floorMod(m, 100L);
        boolean eye = y >= FLOOR + 2 && y <= FLOOR + 4;
        if (isPost(x, z) && !isPostCeiling(seed, x, y, z)) {
            return WALL_SINEW;
        }
        if (zone == ZONE_ARCHIVE && y <= ceilingY(seed, x, z) + 1) {
            if (r < 4 && eye) {
                return WALL_SHROOM;
            }
            if (r < 12 && y <= FLOOR + 3) {
                return WALL_SHELF;
            }
            if (r < 24) {
                return WALL_FLESH;
            }
            return WALL_PLANKS;
        }
        if (r < 3) {
            return r == 0 ? WALL_PLANKS : r == 1 ? WALL_COBBLE : WALL_DIRT;
        }
        if (r < 8 && eye) {
            return WALL_GLOW;
        }
        if (r < 12 && y > FLOOR + 5) {
            return WALL_SCAR;
        }
        return WALL_FLESH;
    }

    private static boolean isPostCeiling(long seed, int x, int y, int z) {
        return y >= ceilingY(seed, x, z) + 2; // solid mass above the ceiling is flesh, posts only show below it
    }
}
