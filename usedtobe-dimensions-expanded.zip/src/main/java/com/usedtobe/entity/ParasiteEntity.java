package com.usedtobe.entity;

import com.usedtobe.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Swims through the flesh walls of brokenmemories. Fast and invisible while buried,
 * slow and frozen the moment you look at it while it's exposed.
 */
public class ParasiteEntity extends Monster {
    private int attackCooldown = 60;
    private int retreatTicks = 0;
    private int lonelyTicks = 0;

    public ParasiteEntity(EntityType<? extends ParasiteEntity> type, Level level) {
        super(type, level);
        this.xpReward = 5;
        this.setNoGravity(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    public void tick() {
        // same trick vexes use: ghost through blocks while ticking
        this.noPhysics = true;
        super.tick();
        this.noPhysics = false;
        this.setNoGravity(true);

        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }

        Player target = server.getNearestPlayer(this, 40.0D);
        if (target == null || target.isSpectator()) {
            this.setDeltaMovement(Vec3.ZERO);
            if (++this.lonelyTicks > 400) {
                this.discard();
            }
            return;
        }
        this.lonelyTicks = 0;

        Vec3 here = this.position().add(0.0D, this.getBbHeight() * 0.5D, 0.0D);
        Vec3 there = target.position().add(0.0D, target.getBbHeight() * 0.5D, 0.0D);
        Vec3 delta = there.subtract(here);
        double dist = delta.length();
        Vec3 dir = dist > 1.0E-4D ? delta.scale(1.0D / dist) : Vec3.ZERO;

        boolean hidden = this.isEmbedded();
        boolean watched = !hidden && this.isWatchedBy(target);

        double speed = hidden ? 0.16D : 0.07D;
        if (watched) {
            speed = 0.0D;
        }

        if (this.retreatTicks > 0) {
            this.retreatTicks--;
            this.setDeltaMovement(dir.scale(-0.2D));
        } else if (dist > 1.5D) {
            this.setDeltaMovement(dir.scale(speed));
        } else {
            this.setDeltaMovement(Vec3.ZERO);
        }

        if (dist > 1.0E-4D) {
            float yaw = (float) (Mth.atan2(-dir.x, dir.z) * (180.0D / Math.PI));
            this.setYRot(yaw);
            this.yBodyRot = yaw;
            this.yHeadRot = yaw;
        }

        this.attackCooldown--;
        if (dist <= 1.9D && this.attackCooldown <= 0 && this.retreatTicks <= 0 && !watched) {
            if (this.doHurtTarget(target)) {
                target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
                target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
            }
            this.attackCooldown = 50;
            this.retreatTicks = 30; // sinks back into the wall
        }

        if (this.tickCount % 12 == 0) {
            server.sendParticles(ParticleTypes.CRIMSON_SPORE, this.getX(), this.getY() + 0.5D, this.getZ(), 2, 0.3D, 0.3D, 0.3D, 0.01D);
        }
        if (this.tickCount % 24 == 0) {
            float vol = (float) Mth.clamp(1.1D - dist / 40.0D, 0.2D, 1.0D);
            server.playSound(null, this.getX(), this.getY(), this.getZ(),
                    ModSounds.vanilla("entity.warden.heartbeat"), SoundSource.HOSTILE, vol, 0.7F);
        }
    }

    private boolean isEmbedded() {
        BlockPos pos = BlockPos.containing(this.getX(), this.getY() + this.getBbHeight() * 0.5D, this.getZ());
        return this.level().getBlockState(pos).isSuffocating(this.level(), pos);
    }

    private boolean isWatchedBy(Player p) {
        Vec3 look = p.getViewVector(1.0F);
        Vec3 to = this.getBoundingBox().getCenter().subtract(p.getEyePosition()).normalize();
        return look.dot(to) > 0.55D && p.hasLineOfSight(this);
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.vanilla("entity.endermite.ambient");
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.vanilla("entity.slime.squish");
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.vanilla("entity.slime.death");
    }
}
