package com.usedtobe;

import net.minecraftforge.common.ForgeConfigSpec;

public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue AUTO_ENTER = B
            .comment("Drop every player into the nostalgia world the first time they join a world.")
            .define("autoEnterOnFirstJoin", true);

    public static final ForgeConfigSpec.IntValue COLLAPSE_MINUTES = B
            .comment("Fallback timer: if you never find enough notebooks, the world collapses on its own after this many minutes.",
                     "On its own the clock only drags the decay about halfway; the notebooks are what really move the story.")
            .defineInRange("collapseMinutes", 90, 5, 480);

    public static final ForgeConfigSpec.IntValue MEMORIES_REQUIRED = B
            .comment("How many of the 10-year-old's notebooks you must find in the nostalgia world to trigger the collapse (max 10).",
                     "The first one is in your old house; every later one is a base further out. Lower = a shorter game.")
            .defineInRange("memoriesRequired", 10, 1, 10);

    public static final ForgeConfigSpec.IntValue NOTEBOOK_DELAY = B
            .comment("Seconds of quiet between finding a notebook and the world revealing where the next one is.")
            .defineInRange("notebookDelaySeconds", 45, 0, 600);

    public static final ForgeConfigSpec.IntValue SITE_DISTANCE = B
            .comment("How far away (in blocks) the next notebook base is placed. It drifts a little further out as the decay deepens.")
            .defineInRange("siteDistance", 110, 40, 400);

    public static final ForgeConfigSpec.IntValue HEARTS_REQUIRED = B
            .comment("How many hearts you must touch in brokenmemories to wake up.")
            .defineInRange("heartsRequired", 5, 1, 8);

    public static final ForgeConfigSpec.DoubleValue FOG_SCALE = B
            .comment("Multiplier for the fog wall that hides the world edge. 1.0 = default, lower = thicker.")
            .defineInRange("fogScale", 1.0D, 0.25D, 4.0D);

    public static final ForgeConfigSpec.BooleanValue CLAMP_RENDER_DISTANCE = B
            .comment("Really lower the client render distance while inside the mod's dimensions (restored on exit).",
                     "If false, only the fog wall is used.")
            .define("clampRenderDistance", true);

    public static final ForgeConfigSpec.IntValue PARASITE_CAP = B
            .comment("Max parasites haunting one player in brokenmemories.")
            .defineInRange("maxParasitesPerPlayer", 4, 1, 12);

    public static final ForgeConfigSpec SPEC = B.build();

    private Config() {}
}
