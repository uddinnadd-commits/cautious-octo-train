package com.usedtobe.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** A stable, hand-activated gateway. Each registered instance points at one dimension. */
public class DimensionPortalBlock extends Block {
    private final ResourceKey<Level> destination;
    private final String destinationName;

    public DimensionPortalBlock(Properties properties, ResourceKey<Level> destination, String destinationName) {
        super(properties);
        this.destination = destination;
        this.destinationName = destinationName;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.CONSUME;
        ServerLevel target = serverPlayer.getServer().getLevel(destination);
        if (target == null) {
            serverPlayer.displayClientMessage(Component.literal("The gateway is silent. Its destination is unavailable."), true);
            return InteractionResult.CONSUME;
        }
        serverPlayer.displayClientMessage(Component.literal("Entering " + destinationName + "..."), true);
        serverPlayer.changeDimension(target);
        return InteractionResult.CONSUME;
    }
}
